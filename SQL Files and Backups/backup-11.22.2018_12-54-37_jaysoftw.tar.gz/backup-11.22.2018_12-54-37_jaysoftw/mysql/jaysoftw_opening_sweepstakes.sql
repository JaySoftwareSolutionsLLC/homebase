-- MySQL dump 10.13  Distrib 5.6.40-84.0, for Linux (x86_64)
--
-- Host: localhost    Database: jaysoftw_opening_sweepstakes
-- ------------------------------------------------------
-- Server version	5.6.40-84.0-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Budget Reviews`
--

DROP TABLE IF EXISTS `Budget Reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Budget Reviews` (
  `entrant` tinytext NOT NULL,
  `service` tinytext NOT NULL,
  `budget` mediumint(8) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Budget Reviews`
--

LOCK TABLES `Budget Reviews` WRITE;
/*!40000 ALTER TABLE `Budget Reviews` DISABLE KEYS */;
INSERT INTO `Budget Reviews` (`entrant`, `service`, `budget`) VALUES ('Adelle Tucker','landing-page',0),('Adelle Tucker','web-application',0),('Adelle Tucker','e-commerce',0),('Adelle Tucker','seo',0),('Brett Brewster','small-website',0),('End','e-commerce',0);
/*!40000 ALTER TABLE `Budget Reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Entries`
--

DROP TABLE IF EXISTS `Entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Entries` (
  `entry` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `email` tinytext NOT NULL,
  `company` tinytext,
  `referrer` tinytext,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`entry`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='This table contains all information about a specific entry';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Entries`
--

LOCK TABLES `Entries` WRITE;
/*!40000 ALTER TABLE `Entries` DISABLE KEYS */;
INSERT INTO `Entries` (`entry`, `name`, `email`, `company`, `referrer`, `time`) VALUES (2,'Adelle Tucker','focusphotography27@gmail.com','Focus Photography by Adelle ','Brett Jay','2018-03-09 20:22:25'),(3,'Brett Brewster','Brettjaybrewster@gmail.com','Bruce Construction','NULL','2018-03-27 02:36:16'),(4,'End','End@end.com','NULL','NULL','2018-04-03 21:16:11');
/*!40000 ALTER TABLE `Entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `General Reviews`
--

DROP TABLE IF EXISTS `General Reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `General Reviews` (
  `entrant` tinytext NOT NULL,
  `service_likelihood` tinyint(4) NOT NULL,
  `service_comments` text,
  `website_review` tinytext,
  `website_comments` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `General Reviews`
--

LOCK TABLES `General Reviews` WRITE;
/*!40000 ALTER TABLE `General Reviews` DISABLE KEYS */;
INSERT INTO `General Reviews` (`entrant`, `service_likelihood`, `service_comments`, `website_review`, `website_comments`) VALUES ('Adelle Tucker',9,'I am looking to create a website that perfectly illustrates my brand - both my photography work and my personality! ','Like','NULL'),('Brett Brewster',6,'NULL','Like','NULL'),('End',8,'NULL','NULL','NULL');
/*!40000 ALTER TABLE `General Reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Services`
--

DROP TABLE IF EXISTS `Services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Services` (
  `service_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='This table contains all of the services that JSS provides';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Services`
--

LOCK TABLES `Services` WRITE;
/*!40000 ALTER TABLE `Services` DISABLE KEYS */;
INSERT INTO `Services` (`service_id`, `name`) VALUES (1,'Landing Page'),(2,'Small Website'),(3,'Web Application'),(4,'eCommerce'),(5,'Online Ordering'),(6,'Responsive Design'),(7,'Search Engine Optimization'),(8,'Logo Animation'),(9,'Custom Software');
/*!40000 ALTER TABLE `Services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'jaysoftw_opening_sweepstakes'
--

--
-- Dumping routines for database 'jaysoftw_opening_sweepstakes'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-22 12:54:38
