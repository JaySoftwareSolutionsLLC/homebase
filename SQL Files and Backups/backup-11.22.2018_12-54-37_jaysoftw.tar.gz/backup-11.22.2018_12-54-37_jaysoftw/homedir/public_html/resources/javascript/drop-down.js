$(document).ready(function() {
	(function() {
	"use strict";
		$('header .mobile img').click(function() {
			$('div.drop-down').toggle();
		});
	})();
});
