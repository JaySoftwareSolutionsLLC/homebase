$(document).ready(function() {
	(function() {
	"use strict";
		$('div.right-side.mobile img').click(function() {
			$('div.drop-down').toggle();
		});
	})();
});
