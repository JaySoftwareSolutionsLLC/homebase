function launch() {
    let shipElement = document.querySelector('g.ship');
    document.querySelector('div.svg-container').style.zIndex = 1005;
    document.querySelector('svg').style.display = 'inline-block';
    document.querySelector('div.loading-button-section').style.display = "none";
    let rotation = 0;
    let direction = 1;
    let shakeFactor = 0.6;
    let maxAngle = 3;
    let y = 0;
    let minAcceleration = 1;
    let maxAcceleration = 3;
    let maxVelocity = 50;
    let velocity = 0;
	let yOffset = shipElement.getBoundingClientRect().y;
    let blastoff = setInterval(function() {
        rotation += (Math.random() * shakeFactor * direction);
        if (rotation > maxAngle) {
            direction *= -1;
            rotation = maxAngle;
        }
        else if (rotation < (-1 * maxAngle)) {
            direction *= -1;
            rotation = -1 * maxAngle;
        }
        if (velocity < maxVelocity) {
            let acceleration = (Math.random() * (maxAcceleration - minAcceleration)) + minAcceleration;
            velocity += acceleration;
        }
        y -= velocity;
        shipElement.setAttribute('transform', `rotate(${rotation}), translate(0, ${y})`);
        if (shipElement.getBoundingClientRect().y < -750) {
            clearInterval(blastoff);
            fadeLoadScreen();
        }
        createSmoke(1);
        createStars(1);
    }, 50)
    function drawCircle(x, y, r, lightness) {
        var svgNS = "http://www.w3.org/2000/svg";
        var circ = document.createElementNS(svgNS,"circle");
        circ.setAttributeNS(null,"cx",x);
        circ.setAttributeNS(null,"cy",y);
        circ.setAttributeNS(null,"r",r);
        circ.setAttributeNS(null,"fill",`hsl(0,0%,${lightness}%)`);
        circ.setAttributeNS(null,"stroke","none");
        circ.setAttributeNS(null,"class","smoke");
        document.querySelector("svg").appendChild(circ);
    }
    function drawSmoke(x, y, lightness) {
        let firstR = 75;
        drawCircle(x, y, firstR, lightness);
        drawCircle((x + (Math.random() * 200) - 100), (y + (Math.random() * 200) - 100), (firstR * Math.random()), lightness);
        drawCircle((x + (Math.random() * 200) - 100), (y + (Math.random() * 200) - 100), (firstR * Math.random()), lightness);
        drawCircle((x + (Math.random() * 200) - 100), (y + (Math.random() * 200) - 100), (firstR * Math.random()), lightness);
        drawCircle((x + (Math.random() * 200) - 100), (y + (Math.random() * 200) - 100), (firstR * Math.random()), lightness);
    }
    function createSmoke(number) {
        for (let i = 0; i < number; i++) {
            let smokeX = 300 + (Math.random() * 400);
            let smokeY = y + 950;
            let smokeL = (Math.random() * 40) + 60;
            drawSmoke(smokeX, smokeY, smokeL);
        }
    }
    function createStars(number) {
        for (let i = 0; i < number; i++) {
            let x = Math.random() * window.innerWidth * 0.95;
            let y = Math.random() * window.innerHeight * 0.4;
            let s = Math.random() * 5;
            let r = Math.random() * 90;
            createStar(x, y, s, r);
        }
    }
    function createStar(x, y, size, rotation) {
        var star = document.createElement("div");
        star.setAttribute("class","star");
        star.setAttribute("style",`height : ${size}px; width: ${size}px; left: ${x}px; top: ${y}px; transform: rotate(${rotation}deg);`);
        document.querySelector("body").appendChild(star);
    }
    function fadeLoadScreen() {
        let slideFade = 2000;
        let slideDelay = 200;
        setTimeout(function() {
            let topElement = document.querySelector('div.loading-section-top');
            topElement.style.transition = `${slideFade}ms all`;
            topElement.style.height = '80px';
            topElement.style.opacity = 0.5;
            let botElement = document.querySelector('div.loading-section-bottom');
            botElement.style.transition = `${slideFade}ms all`;
            botElement.style.opacity = 0;
            let starElements = document.querySelectorAll('div.star');
            for (let s of starElements) {
                s.style.display = "none";
            }
            window.scrollTo(0, 0);
        }, slideDelay);
        let disappearDelay = 2200;
        setTimeout(function() {
            let lsElement = document.querySelector('section.loading-screen');
            let svgContElement = document.querySelector('div.svg-container');
            lsElement.style.transition = `0ms all`;
            lsElement.style.display = 'none';
            svgContElement.style.display = 'none';
        }, disappearDelay)
    }
}
