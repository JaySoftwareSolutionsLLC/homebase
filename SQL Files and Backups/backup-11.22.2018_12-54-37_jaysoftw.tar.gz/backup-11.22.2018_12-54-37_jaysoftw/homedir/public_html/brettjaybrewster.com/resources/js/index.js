function removeLoadingScreen() {
    setTimeout(function() {
        document.querySelector('.loading-section-top h1').style.opacity = 0;
        document.querySelector('.loading-section-top h2').style.opacity = 0;
        document.querySelector('.loading-button-section button .btn-txt').style.opacity = 0;
    }, 0);
    setTimeout(function() {
        launch();
    }, 200);
}
document.querySelector('body').onscroll = checkActiveLink;
function checkActiveLink() {
    let aboutEl = document.querySelector('section.jumbotron');
    let abBounding = aboutEl.getBoundingClientRect();
    if (abBounding['y'] <= 225 && abBounding['y'] >= -40) {
        changeActiveLink('about_nav');
    }
    let skillsEl = document.querySelector('section.skills');
    let skBounding = skillsEl.getBoundingClientRect();
    if (skBounding['y'] <= 225 && skBounding['y'] >= -40) {
        changeActiveLink('skills_nav');
    }
    let portEl = document.querySelector('section.portfolio');
    let ptBounding = portEl.getBoundingClientRect();
    if (ptBounding['y'] <= 225 && ptBounding['y'] >= -40) {
        changeActiveLink('portfolio_nav');
    }
};
function changeActiveLink(id) {
    let els = document.querySelectorAll('header a');
    for (let el of els) {
        el.classList.remove("current");
    }
    let e = document.querySelector(`#${id}`);
    e.classList.add("current");
}
function animateMap() {
    let i = 3;
    setInterval(function() {
        let e = document.querySelector(`.hobbies .content .exploring .trail:nth-child(${i})`);
        if (e.style.opacity == 0) {
            e.style.opacity = 1;
        }
        else {
            e.style.opacity = 0;
        }
        i++;
        if (i === 9) {
            let treasureEl = document.querySelector('.hobbies .content .exploring .treasure');
            if (treasureEl.style.opacity == 0) {
                treasureEl.style.opacity = 1;
            }
            else {
                treasureEl.style.opacity = 0;
            }
            i = 3;
        }
    }, 400)
}
animateMap();
function animateMonitor() {
    let i = 5;
    setInterval(function() {
        let e = document.querySelector(`.hobbies .content .coding .svg-code-text:nth-child(${i})`);
        if (e.style.opacity == 0) {
            e.style.opacity = 1;
        }
        else {
            e.style.opacity = 0;
        }
        i++;
        if (i === 11) {
            i = 5;
        }
    }, 1000)
}
document.onmousemove = function(e){
    let x = e.clientX;
    let y = e.clientY;
    let w = window.innerWidth;
    let h = window.innerHeight;
    let xPer = Math.floor((x / w) * 86);
    let yPer = Math.floor((y / h) * 58);
    let cursorEl = document.querySelector('svg path.cursor');
    cursorEl.style.transform = `translate(${xPer}px,${yPer}px)`;

}
function pumpIron() {
    let deg = 0;
    setInterval(function() {
        let e = document.querySelector('g.forearm-and-weight');
        e.setAttribute('transform', `rotate(${deg} 67 100)`);
        deg++;
    }, 100)
}
pumpIron();
