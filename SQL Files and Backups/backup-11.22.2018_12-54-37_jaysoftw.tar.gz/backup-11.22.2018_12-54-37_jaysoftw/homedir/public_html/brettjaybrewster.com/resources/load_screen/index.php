<svg xmlns='http://www.w3.org/2000/svg' xmlns:xlink="http://www.w3.org/1999/xlink" viewBox='0 0 100 100' height="100px" width="100px">
<!--	<a <strong>xlink:href="http://www.jaysoftwaresolutions.com"</strong>>-->
	<defs>
    	<style>

		</style>
    </defs>

    <g class="nucleus" transform="translate(50, 50)">
        <circle cx="0" cy="0" r="3" fill="black" />
        <circle cx="2" cy="2" r="3" fill="black" />
        <circle cx="-1" cy="3" r="3" fill="black" />
        <circle cx="-2" cy="-3" r="3" fill="black" />
    </g>
    <ellipse cx="50" cy="50" rx="15" ry="40" stroke="red" fill="none" stroke-width="5"/>
    <circle id="elec_1" cx="50" cy="10" r="3" fill="red"/>
    <ellipse cx="50" cy="50" rx="15" ry="40" stroke="green" fill="none" transform="rotate(120 50 50)" stroke-width="5"/>
    <circle id="elec_2" cx="84.64" cy="70" r="3" fill="green"/>
    <ellipse cx="50" cy="50" rx="15" ry="40" stroke="blue" fill="none" transform="rotate(60 50 50)" stroke-width="5"/>
    <circle id="elec_3" cx="15.36" cy="70" r="3" fill="blue"/>
    </svg>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/1.20.3/TweenMax.min.js"></script>
	<!-- <script src="resources/js/logo_animation.js"></script> -->
