<link href="resources/css/portfolio.css" rel="stylesheet"/>

<section class="portfolio" id="portfolio">
    <h2>Portfolio</h2>
    <div class="content">
       <div class="project">
            <h3>Home Base 3.0</h3>
            <img src="resources/assets/images/picture-homebase.png" alt="Screenshot of Home Base 3.0">
            <span class="rel-skills"><h6>Relevant Skills:</h6>
                <img src="resources/assets/images/graphic-php.png" alt="PHP logo">
                <img src="resources/assets/images/graphic-sql.png" alt="SQL logo">
                <img src="resources/assets/images/graphic-html.png" alt="HTML logo">
                <img src="resources/assets/images/graphic-css.png" alt="CSS logo">
                <img src="resources/assets/images/graphic-js.png"  alt="JavaScript logo">
                <img src="resources/assets/images/graphic-jquery.png" alt="jQuery logo">
                <img src="resources/assets/images/graphic-cpanel.png" alt="CPanel logo">
                <img src="resources/assets/images/graphic-svg.png" alt="SVG logo">
                <img src="resources/assets/images/graphic-git.png" alt="Git logo">
            </span>
            <p>Home Base 3.0 is the third iteration of a project that is used to track progress towards goals. This web application allows the user to track and measure progress towards financial and fitness goals. It combines muscle-fatigue tracking with circumference measurements to visually display which muscles are in recovery as well as generate comprehensive workouts based on my time-availability; track income and expenditures to make financial projections; visually display account allocations; infer progress towards goals and measure that against linear-derived necessary progress; show the number of beautiful days/nights and current weather in different cities; generate weekly and monthly reports to track progress and key performance indicators. It is also responsive which allows the user to easily access and submit information from mobile devices on the go.</p>
            <button>Interactive Demonstration Coming Soon</button>
            <!--<a href="https://youtu.be/vf89VMZdmMU" target="_blank" >--><button>Video Demonstration Coming Soon</button><!--</a>-->
        </div>
        <div class="project">
            <h3>Seed to Market</h3>
            <img src="resources/assets/images/picture-seed_to_market.png" alt="Screenshot of Seed to Market Application">
            <span class="rel-skills"><h6>Relevant Skills:</h6>
                <img src="resources/assets/images/graphic-laravel.png" alt="Laravel logo">
                <img src="resources/assets/images/graphic-php.png" alt="PHP logo">
                <img src="resources/assets/images/graphic-sql.png" alt="SQL logo">
                <img src="resources/assets/images/graphic-html.png" alt="HTML logo">
                <img src="resources/assets/images/graphic-css.png" alt="CSS logo">
                <img src="resources/assets/images/graphic-js.png"  alt="JavaScript logo">
                <img src="resources/assets/images/graphic-git.png" alt="Git logo">
            </span>
            <p>Seed To Market is a management system for a hypothetical farm. It tracks multiple performance indicators and inventories for the farm and displays important statistics via a dashboard, including: extrapolated annual profit projections, how on track the farm is to hit its financial goals and which plants have the highest earning potential just to name a few! This project was my first experience with the Laravel framework and helped reiterate that frameworks can be extremely powerful tools to expedite a project.</p>
            <a href="https://youtu.be/vf89VMZdmMU" target="_blank" ><button>Video Demonstration</button></a>
        </div>
		<div class="project">
			<h3>Retirement Security Calculator</h3>
			<img src="resources/assets/images/picture-retirement_security_calculator.png" alt="Screenshot of Retirement Security Calculator">
			<span class="rel-skills"><h6>Relevant Skills:</h6>
				<img src="resources/assets/images/graphic-html.png" alt="HTML logo">
				<img src="resources/assets/images/graphic-css.png" alt="CSS logo">
				<img src="resources/assets/images/graphic-js.png"  alt="JavaScript logo">
			</span>
			<p>Retirement Security Calculator is an application I created to allow users to determine how large of a nest egg they need to retire comfortably based on their desired annual retirement income. It contains historical data from 1950 through 2017 including inflation rates and stock market returns. It uses that information to simulate the past 68 years and determine how likely it is that a retiree's money will be sufficient over 5 year intervals. This helps retirees understand how much money is safe to withdraw annually from their account and also helps young adults determine what their retirement target should be.</p>
			<button>Video Demonstration Coming Soon</button>
		</div>
		<div class="project">
			<h3>2D Projectile Motion Simulator</h3>
			<img src="resources/assets/images/picture-2D_projectile_motion.png" alt="Screenshot of 2D Projectile Motion Simulator">
			<span class="rel-skills"><h6>Relevant Skills:</h6>
				<img src="resources/assets/images/graphic-html.png" alt="HTML logo">
				<img src="resources/assets/images/graphic-css.png" alt="CSS logo">
				<img src="resources/assets/images/graphic-js.png"  alt="JavaScript logo">
			</span>
			<p>2D Projectile Motion Simulator is precisely what it sounds like. The application allows the user to input starting conditions such as height, displacement, angle and velocity. It also allows the user to input environmental conditions such as the gravitational force, drag medium and projectile's shape. It then uses these values to create a real-time simulation. The color of the path can be changed for each simulation run so that multiple simulations can be run and compared to one another.</p>
			<a href="https://youtu.be/bW1kKqn7Rjs" target="_blank" ><button>Video Demonstration</button></a>
		</div>
<!--
        <div class="project">
            <div class="project-content">
                <h3>The Rich Road</h3>
                <img src="resources/assets/images/picture-blank_black.png">
                <span class="rel-skills"><h6>Relevant Skills:</h6>
                    <img src="resources/assets/images/graphic-html.png" alt="HTML logo">
                    <img src="resources/assets/images/graphic-css.png" alt="CSS logo">
                    <img src="resources/assets/images/graphic-js.png"  alt="JavaScript logo">
                    <img src="resources/assets/images/graphic-php.png" alt="PHP logo">
                    <img src="resources/assets/images/graphic-sql.png" alt="SQL logo">
                    <img src="resources/assets/images/graphic-git.png" alt="Git logo">
                </span>
                <p>The Rich Road is a website I created to give the everyday person the tools to become knowledgeable and responsible with their money. There are multiple tools on this website that simulate financial scenerios based on inflation and the stock market. It helped push my problem-solving ability using both JavaScript and PHP as well as increase my awareness of how affiliate marketing works.</p>
            </div>
            <a href="" target="_blank" ><button>Open Website</button></a>
        </div>
-->
        <div class="project">
            <h3>Jay Software Solutions</h3>
            <img src="resources/assets/images/picture-jay_software_solutions.jpg" alt="Screenshot of Jay Software Solutions Homepage">
            <span class="rel-skills"><h6>Relevant Skills:</h6>
                <img src="resources/assets/images/graphic-html.png" alt="HTML logo">
                <img src="resources/assets/images/graphic-css.png" alt="CSS logo">
                <img src="resources/assets/images/graphic-js.png"  alt="JavaScript logo">
                <img src="resources/assets/images/graphic-php.png" alt="PHP logo">
                <img src="resources/assets/images/graphic-sql.png" alt="SQL logo">
                <img src="resources/assets/images/graphic-git.png" alt="Git logo">
                <img src="resources/assets/images/graphic-svg.png" alt="SVG logo">
            </span>
            <p>Jay Software Solutions is a website for a LLC that I founded to help me refine my development skills and dip my toes into business while doing some local client-work and deploying online sites. It helped me get a more thorough understanding of developing a website that is aligned with a business plan.</p>
            <a href="https://jaysoftwaresolutions.com/" target="_blank" ><button>Open Website</button></a>
        </div>
        <div class="project">
            <h3>PYT Dance Studio</h3>
            <img src="resources/assets/images/picture-dance_studio.jpg" alt="Screenshot of PYT Dance Studio Project">
            <span class="rel-skills"><h6>Relevant Skills:</h6>
                <img src="resources/assets/images/graphic-html.png" alt="HTML logo">
                <img src="resources/assets/images/graphic-css.png" alt="CSS logo">
                <img src="resources/assets/images/graphic-bootstrap.png" alt="Bootstrap logo">
                <img src="resources/assets/images/graphic-git.png" alt="Git logo">
            </span>
            <p>PYT Dance Studio is a promotional website for a hypothetical dance company. It was the first multi-page website that I coded. It was made as a capstone project for an online course and was my first project using the bootstrap framework. I've improved my skills quite a bit since it was completed back in March of 2017 but I still look back at it as my first relatively professional project.</p>
            <a href="/pyt_dance_studio/index.html" target="_blank" ><button>Open Website</button></a>
        </div>
    </div>
</section>
