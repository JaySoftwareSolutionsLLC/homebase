<link href="resources/css/header.css" rel="stylesheet"/>

<header>
    <a href="#about" class="current" id="about_nav"><h2>About</h2></a>
    <!-- | -->
    <a href="resources/Resume.pdf" id="resume_nav" target="_blank"><h2>Résumé</h2></a>
    <!-- | -->
    <a href="#skills" id="skills_nav"><h2>Skills</h2></a>
    <!-- | -->
    <a href="#portfolio" id="portfolio_nav"><h2>Portfolio</h2></a>
</header>
