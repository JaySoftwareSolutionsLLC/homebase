<link href="resources/css/hobbies.css" rel="stylesheet"/>

<section class="hobbies" id="hobbies">
    <h2>Hobbies</h2>
    <div class='content'>
        <div class='hobby basketball'>
            <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                <defs>
                    <linearGradient id="Gradient1" x1="0%" y1="0%" x2="100%" y2="100%">
                         <stop offset="0%" style="stop-color:hsl(20, 100%, 45%)"/>
                         <stop offset="100%" style="stop-color:hsl(20, 100%, 60%)"/>
                    </linearGradient>
                    <linearGradient id="Gradient2" x1="0%" y1="0%" x2="100%" y2="100%">
                         <stop offset="0%" style="stop-color:hsl(40, 100%, 40%)"/>
                         <stop offset="100%" style="stop-color:hsl(40, 100%, 70%)"/>
                    </linearGradient>
                    <linearGradient id="Gradient3" x1="0%" y1="0%" x2="100%" y2="100%">
                         <stop offset="0%" style="stop-color:hsl(0, 0%, 0%)"/>
                         <stop offset="100%" style="stop-color:hsl(0, 0%, 25%)"/>
                    </linearGradient>
                    <linearGradient id="Gradient4" x1="0%" y1="0%" x2="100%" y2="100%">
                         <stop offset="0%" style="stop-color:hsl(0, 0%, 20%)"/>
                         <stop offset="100%" style="stop-color:hsl(0, 0%, 50%)"/>
                    </linearGradient>
                    <linearGradient id="Gradient5" x1="0%" y1="100%" x2="100%" y2="0%">
                         <stop offset="0%" style="stop-color:orange"/>
                         <stop offset="100%" style="stop-color:peach"/>
                    </linearGradient>
                </defs>
                <g class="basketball">
                    <circle cx="50" cy="50" r="40"/>
                    <path d="M 47,10 C 12,39 22,68 42,90" fill="none"/>
                    <path d="M 10,55 C 20,65 52,64 90,48" fill="none"/>
                    <path d="M 13,33 C 24,80 52,16 81,25" fill="none"/>
                    <path d="M 19,75 C 23,58 46,87 78,78" fill="none"/>
                </g>
            </svg>
            <h3>Basketball</h3>
        </div>
        <div class='hobby exploring'>
            <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                <g>
                    <path d="
                                M 18,1
                                C 37,13 62,15 83,6
                                C 100,19 74,32 82,46
                                L 74,51
                                L 80,57
                                Q 66,69 92,86
                                Q 87,97 74,93
                                L 62,83
                                L 67,94
                                C 50,84 25,111 8,83
                                L 20,83
                                C 29,89 0,61 23,31
                                L 35,29
                                L 26,25
                                C 22,22 22,12 12,3
                                L 18,1
                                "/>
                    <path class="treasure" fill="red" d="
                                M 36,59
                                L 42,49
                                L 51,55
                                L 43,63
                                L 55,68
                                L 47,75
                                L 38,70
                                L 32,76
                                L 25,73
                                L 32,64
                                L 23,60
                                L 26,53
                                L 36,59"
                                />
                    <line class="trail" x1="61" y1="17" x2="64" y2="24"/>
                    <line class="trail" x1="65" y1="28" x2="62" y2="35"/>
                    <line class="trail" x1="58" y1="35" x2="51" y2="33"/>
                    <line class="trail" x1="47" y1="35" x2="42" y2="39"/>
                    <line class="trail" x1="40" y1="42" x2="35" y2="46"/>
                    <line class="trail" x1="35" y1="49" x2="36" y2="55"/>
                </g>
            </svg>
            <h3>Exploring</h3>
        </div>
        <div class='hobby lifting'>
            <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                <g class="forearm-and-weight" fill="#ccc">
                    <circle class="weight" cx="32" cy="37" r="15"/>
                    <circle class="weight" cx="29" cy="40" r="15"/>
                    <path class="arm" d=" M 21,37
                                            C 35,37 32,50 35,55
                                            L 47,65
                                            Q 57,61 66,69
                                            L 67,100
                                            C 40,95 35,70 19,51"/>
                    <line x1="34" y1="60" x2="40" y2="64" />
                    <path fill="none" d="M 46,79 C 51,92 65,93 65,85" />
                    <circle class="weight" cx="21" cy="49" r="17"/>
                    <circle class="weight" cx="18" cy="52" r="17"/>
                    <circle class="weight" cx="18" cy="52" r="3" />
                </g>
                <path class="arm" d=" M 66,67
                Q 60,36 80,30
                Q 74,9 90,3
                Q 85,29 100,53
                C 92,78 73,94 66,100"/>
                <path fill="none" d="   M 72,66
                            C 74,74 88,65 87,46" />
            </svg>
            <h3>Lifting</h3>
        </div>
        <div class='hobby coding'>
            <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                <g class="monitor" fill="none">
                    <rect x="3" y="3" width="94" height="72" rx="5" ry="5" fill="url(#Gradient3)"/>
                    <rect x="3" y="69" width="94" height="6" rx="2" ry="2" fill="white"/>
                    <rect x="40" y="75" width="20" height="15" fill="white"/>
                    <rect x="30" y="90" width="40" height="3" rx="2" ry="2" fill="white"/>
                    <path class="cursor" d="M 5,5 L 5,14 L 8,12 L 11,18 L 8,12 L 11,12 L 5,5" fill="white"/>
                </g>
            </svg>
            <h3>Programming</h3>
        </div>
    </div>
</section>
