<link href="resources/css/footer.css" rel="stylesheet"/>

<footer>
    Hand coded by Brett Brewster ©<?php echo date("Y");?>
</footer>
