<link href="resources/css/skills.css" rel="stylesheet"/>

<section class="skills" id="skills">
    <h2>Technical Skills</h2>
    <section class="languages">
        <!-- <h3>Languages:</h3> -->
        <div class="row">
            <div class="unit">
                <img src="resources/assets/images/graphic-html.png" alt="HTML logo">
                <h4>HTML(5)</h4>
            </div>
            <div class="unit">
                <img src="resources/assets/images/graphic-css.png" alt="CSS logo">
                <h4>CSS(3)</h4>
            </div>
            <div class="unit">
                <img src="resources/assets/images/graphic-js.png" alt="JavaScript logo">
                <h4>JS</h4>
            </div>
            <div class="unit">
                <img src="resources/assets/images/graphic-php.png" alt="PHP logo">
                <h4>PHP</h4>
            </div>
            <!-- <div class="unit">
                <img src="resources/assets/images/graphic-sql.png">
                <h4>SQL</h4>
            </div> -->
        </div>
    </section>
    <section class="technologies">
        <!-- <h3>Frameworks, Libraries & DBMSs:</h3> -->
        <div class="row">
            <div class="unit">
                <img src="resources/assets/images/graphic-git.png" alt="Git logo">
                <h4>Git</h4>
            </div>
            <div class="unit">
                <img src="resources/assets/images/graphic-sql.png" alt="MySQL logo">
                <h4>MySQL</h4>
            </div>
            <div class="unit">
                <img src="resources/assets/images/graphic-sql-server.png" alt="SQL Server logo">
                <h4>SQL Server</h4>
            </div>
            <div class="unit cpanel">
                <img src="resources/assets/images/graphic-cpanel.png" alt="CPanel logo">
                <h4>cPanel</h4>
            </div>
            <div class="unit">
                <img src="resources/assets/images/graphic-dreamweaver.png" alt="Dreamweaver logo">
                <h4>Adobe Dreamweaver</h4>
            </div>
            <div class="unit">
                <img src="resources/assets/images/graphic-laravel.png" alt="Laravel logo">
                <h4>Laravel</h4>
            </div>
            <div class="unit">
                <img src="resources/assets/images/graphic-xampp.png" alt="XAMPP logo">
                <h4>XAMPP</h4>
            </div>
            <div class="unit">
                <img src="resources/assets/images/graphic-jquery.png" alt="jQuery logo">
                <h4>jQuery</h4>
            </div>
            <div class="unit">
                <img src="resources/assets/images/graphic-bootstrap.png" alt="Bootstrap logo">
                <h4>Bootstrap</h4>
            </div>
            <div class="unit">
                <img src="resources/assets/images/graphic-greensock.png" alt="Greensock logo">
                <h4>Greensock</h4>
            </div>
            <div class="unit">
                <img src="resources/assets/images/graphic-svg.png" alt="SVG logo">
                <h4>SVG</h4>
            </div>
        </div>
    </section>
</section>
