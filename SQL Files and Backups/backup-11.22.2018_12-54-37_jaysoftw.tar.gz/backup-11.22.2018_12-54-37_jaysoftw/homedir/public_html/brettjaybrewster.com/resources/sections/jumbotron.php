<link href="resources/css/jumbotron.css" rel="stylesheet"/>

<section class="jumbotron" id="about">
    <h2>About Me</h2>
    <img src="resources/assets/images/picture-brett_professional.jpg">
    <div class="text">
        <p>Hi! My name is Brett Brewster. I was born and raised in East Aurora, NY and I have a physics Baccalaureate. Throughout my time studying physics I became fascinated with the power and utility of using computers to help solve problems. I have been learning new technologies, languages and methodologies ever since. I have designed and coded projects that simulate investing based on historical data and trends, track and generate workouts based on muscle readiness, and generate powerful predictive business estimates, just to name a few! Check out my <a href="#portfolio">portfolio</a> to get an in depth view of the projects that I'm most proud of. I am hard-working and intelligent, and my bosses & colleagues frequently express that I am a great "team player", "highly motivated" and a "fast learner".</p>
        <a href="resources/Resume.pdf" target="_blank"><button>Résumé</button></a>
    </div>
</section>
