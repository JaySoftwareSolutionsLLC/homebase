<link href="resources/css/load_screen.css" rel="stylesheet"/>
<!-- <script src="resources/js/processing.js"></script> -->
<!-- <canvas data-processing-sources="resources/js/loading_screen.pde">
</canvas> -->
<section class='loading-screen'>
    <div class='loading-section loading-section-top'>
        <h1>Brett Brewster's</h1>
        <h2>Portfolio <span class="gold">|</span> Résumé <span class="gold">|</span> Expertise</h2>
    </div>
    <div class='loading-section loading-section-bottom'></div>
    <div class="loading-button-section">
        <button id="loaded-button" onclick="removeLoadingScreen()"><span class="btn-txt">Launch</span></button>
    </div>
</section>

<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
<!-- <script type="text/javascript" src="resources/js/bouncing_balls.js"></script> -->
<div class="svg-container">
    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 1000 1000" class="rocket">
        <defs>
            <style>
                @import url('resources/css/reset.css');
                @import url('resources/css/svg.css');
            </style>
        </defs>
        <g class="ship">
            <polygon points="300,300 500,50 700,300" fill="grey" />
            <path d="M 100,700 A 400,400 0 0,1 900,700 A 400,100 0 1,0 100,700" stroke="none" fill="grey"/>
            <path d="M 300,850
            Q 275,875 350,920 Q 375,890 400,895
            Q 385,925 500,950 Q 615,925 600,895
            Q 650,890 650,920 Q 725,875 700,850 z" class="flames" fill="red"/>
            <!-- <path d="M 320,850 Q 285,875 340,900 Q 350,820 500,850 z" fill="orange"/> -->
            <polygon points="400,700 600,700 700,850 300,850" fill="grey" />
            <circle cx="500" cy="500" r="300" fill="hsl(44, 100%, 50%)" />
            <!-- <text x="500" y="500" fill="black">Launch</text> -->
            <!-- <path d="M 300,850 A 50,90 0 1,0 400,850" fill="red"/> -->
            <!-- <path d="M500,500 a 150,150 0 0,1 50,50" fill="green"/> -->
        </g>
    </svg>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/1.20.3/TweenMax.min.js"></script>
    <script src="resources/js/svg.js"></script>
</div>
