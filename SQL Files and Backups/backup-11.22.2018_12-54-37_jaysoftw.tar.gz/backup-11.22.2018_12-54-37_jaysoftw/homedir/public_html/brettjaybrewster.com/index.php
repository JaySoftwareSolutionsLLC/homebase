<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Brett Brewster | Software Developer</title>
    <link rel="shortcut icon" href="resources/assets/images/favicon.png" type="image/x-icon"/>
    <link href="resources/css/reset.css" rel="stylesheet"/>
    <link href="resources/css/main.css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Titillium+Web|Norican" rel="stylesheet">
</head>
<body class="">
    <?php
    include('resources/sections/load_screen.php');
    include('resources/sections/header.php');
    include('resources/sections/jumbotron.php');
    include('resources/sections/skills.php');
    include('resources/sections/portfolio.php');
    include('resources/sections/hobbies.php');
    include('resources/sections/footer.php');
    ?>
    <script type="text/javascript" src="resources/js/index.js"></script>
</body>
</html>
