<section class="column habits" style="display:none;">
	<h2>Habits</h2>
</section>