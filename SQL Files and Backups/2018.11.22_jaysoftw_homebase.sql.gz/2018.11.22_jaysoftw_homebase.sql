-- MySQL dump 10.13  Distrib 5.6.40-84.0, for Linux (x86_64)
--
-- Host: localhost    Database: jaysoftw_homebase
-- ------------------------------------------------------
-- Server version	5.6.40-84.0-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `finance_accounts`
--

DROP TABLE IF EXISTS `finance_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `finance_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `name` tinytext NOT NULL,
  `value` mediumint(8) unsigned NOT NULL,
  `type` enum('cash','asset','liability') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=169 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `finance_accounts`
--

LOCK TABLES `finance_accounts` WRITE;
/*!40000 ALTER TABLE `finance_accounts` DISABLE KEYS */;
INSERT INTO `finance_accounts` (`id`, `date`, `name`, `value`, `type`) VALUES (1,'2018-06-06','BoA Savings',4542,'cash'),(2,'2018-06-06','Great Lakes Loans',13012,'liability'),(3,'2018-06-05','Schwab ROTH',18103,'asset'),(4,'2018-06-05','Schwab Beneficiary',250,'asset'),(5,'2018-06-06','Cash',213,'cash'),(6,'2018-06-06','Schwab Checking',2307,'cash'),(7,'2018-06-07','Schwab ROTH',18192,'asset'),(8,'2018-06-10','Schwab ROTH',18225,'asset'),(9,'2018-06-10','Schwab Checking',2230,'cash'),(10,'2018-06-10','BoA Savings',4542,'cash'),(11,'2018-06-10','Cash',703,'cash'),(12,'2018-06-17','BoA Savings',4542,'cash'),(13,'2018-06-17','Cash',1429,'cash'),(14,'2018-06-17','Schwab Beneficiary',250,'asset'),(15,'2018-06-17','Schwab Checking',1278,'cash'),(16,'2018-06-17','Schwab ROTH',18112,'asset'),(17,'2018-06-17','Great Lakes Loans',13029,'liability'),(18,'2018-06-24','BoA Savings',5844,'cash'),(19,'2018-06-24','Cash',1632,'cash'),(20,'2018-06-24','Great Lakes Loans',13039,'liability'),(21,'2018-06-24','Schwab Beneficiary',250,'asset'),(22,'2018-06-24','Schwab Checking',1218,'cash'),(23,'2018-06-24','Schwab ROTH',17996,'asset'),(24,'2018-06-27','BoA Savings',7144,'cash'),(25,'2018-06-27','Cash',446,'cash'),(26,'2018-07-01','Great Lakes Loans',13048,'liability'),(27,'2018-07-01','Schwab Beneficiary',250,'asset'),(28,'2018-07-01','Schwab Checking',1089,'cash'),(29,'2018-07-01','Schwab ROTH',17789,'asset'),(30,'2018-07-01','Cash',841,'cash'),(31,'2018-07-01','BoA Savings',7144,'cash'),(32,'2018-07-05','Schwab Beneficiary',250,'asset'),(33,'2018-07-05','Schwab ROTH',17839,'asset'),(34,'2018-07-05','Schwab Checking',1021,'cash'),(35,'2018-07-05','BoA Savings',9146,'cash'),(36,'2018-07-05','Cash',102,'cash'),(37,'2018-07-10','BoA Savings',4750,'cash'),(38,'2018-07-10','Cash',443,'cash'),(39,'2018-07-10','Great Lakes Loans',13060,'liability'),(40,'2018-07-10','Schwab Beneficiary',250,'asset'),(41,'2018-07-10','Schwab Checking',5159,'cash'),(42,'2018-07-10','Schwab ROTH',18133,'asset'),(43,'2018-07-14','Schwab Checking',1772,'cash'),(44,'2018-07-14','Great Lakes Loans',9565,'liability'),(45,'2018-07-22','BoA Savings',4750,'cash'),(46,'2018-07-22','Cash',655,'cash'),(47,'2018-07-22','Great Lakes Loans',9573,'liability'),(48,'2018-07-22','Schwab Beneficiary',250,'asset'),(49,'2018-07-22','Schwab ROTH',18048,'asset'),(50,'2018-07-22','Schwab Checking',1756,'cash'),(51,'2018-07-25','BoA Savings',6052,'cash'),(52,'2018-07-25','Cash',770,'cash'),(53,'2018-07-25','Schwab Beneficiary',250,'asset'),(54,'2018-07-25','Schwab ROTH',18210,'asset'),(55,'2018-07-25','Schwab Checking',1638,'cash'),(56,'2018-07-25','Great Lakes Loans',9576,'liability'),(57,'2018-08-04','BoA Savings',6715,'cash'),(58,'2018-08-04','Cash',716,'cash'),(59,'2018-08-04','Great Lakes Loans',9585,'liability'),(60,'2018-08-04','Schwab Beneficiary',250,'asset'),(61,'2018-08-04','Schwab Checking',1063,'cash'),(62,'2018-08-04','Schwab ROTH',18159,'asset'),(63,'2018-08-12','BoA Savings',7796,'cash'),(64,'2018-08-12','Cash',578,'cash'),(65,'2018-08-12','Great Lakes Loans',9593,'liability'),(66,'2018-08-12','Schwab Beneficiary',250,'asset'),(67,'2018-08-12','Schwab Checking',879,'cash'),(68,'2018-08-12','Schwab ROTH',18006,'asset'),(69,'2018-08-16','BoA Savings',9146,'cash'),(70,'2018-08-16','Cash',615,'cash'),(71,'2018-08-16','Schwab Beneficiary',250,'asset'),(72,'2018-08-16','Schwab Checking',1264,'cash'),(73,'2018-08-16','Schwab ROTH',17916,'asset'),(74,'2018-08-16','Great Lakes Loans',9597,'liability'),(75,'2018-08-24','Schwab ROTH',18218,'asset'),(76,'2018-08-24','Schwab Checking',1099,'cash'),(77,'2018-08-24','Cash',902,'cash'),(78,'2018-08-26','Cash',1318,'cash'),(79,'2018-08-26','Schwab Checking',960,'cash'),(80,'2018-09-02','BoA Savings',5480,'cash'),(81,'2018-09-02','Schwab Checking',4932,'cash'),(82,'2018-09-09','Schwab ROTH',17958,'asset'),(83,'2018-09-09','Schwab Beneficiary',250,'asset'),(84,'2018-09-09','Schwab Checking',5619,'cash'),(85,'2018-09-09','BoA Savings',6980,'cash'),(86,'2018-09-09','Cash',217,'cash'),(87,'2018-09-09','Great Lakes Loans',9620,'liability'),(88,'2018-09-12','BoA Savings',8811,'cash'),(89,'2018-09-12','Cash',377,'cash'),(90,'2018-09-12','Great Lakes Loans',5002,'liability'),(91,'2018-09-12','Schwab ROTH',18062,'asset'),(92,'2018-09-12','Schwab Checking',916,'cash'),(93,'2018-09-12','Schwab Beneficiary',250,'asset'),(94,'2018-09-23','BoA Savings',10111,'cash'),(95,'2018-09-23','Cash',227,'cash'),(96,'2018-09-23','Great Lakes Loans',5008,'liability'),(97,'2018-09-23','Schwab ROTH',18383,'asset'),(98,'2018-09-23','Schwab Checking',683,'cash'),(99,'2018-09-23','Schwab Beneficiary',250,'asset'),(100,'2018-09-26','BoA Savings',7320,'cash'),(101,'2018-09-26','Cash',338,'cash'),(102,'2018-09-26','Schwab Checking',4696,'cash'),(103,'2018-09-26','Schwab ROTH',18233,'asset'),(104,'2018-09-30','BoA Savings',7320,'cash'),(105,'2018-09-30','Cash',1015,'cash'),(106,'2018-09-30','Great Lakes Loans',5011,'liability'),(107,'2018-09-30','Schwab Beneficiary',250,'asset'),(108,'2018-09-30','Schwab ROTH',18253,'asset'),(109,'2018-10-03','BoA Savings',7320,'cash'),(110,'2018-10-03','Schwab Checking',1059,'cash'),(111,'2018-10-03','Schwab Beneficiary',250,'asset'),(112,'2018-10-03','Schwab ROTH',18241,'asset'),(113,'2018-10-03','Great Lakes Loans',2215,'liability'),(114,'2018-10-03','Cash',1210,'cash'),(115,'2018-10-07','BoA Savings',8830,'cash'),(116,'2018-10-07','Cash',215,'cash'),(117,'2018-10-07','Schwab ROTH',17936,'asset'),(118,'2018-10-07','Schwab Checking',959,'cash'),(119,'2018-10-13','BoA Savings',10150,'cash'),(120,'2018-10-13','Great Lakes Loans',2217,'liability'),(121,'2018-10-13','Schwab Beneficiary',250,'asset'),(122,'2018-10-13','Schwab Checking',825,'cash'),(123,'2018-10-13','Schwab ROTH',17359,'asset'),(124,'2018-10-13','Cash',968,'cash'),(125,'2018-10-20','Schwab Beneficiary',250,'asset'),(126,'2018-10-20','Schwab ROTH',17360,'asset'),(127,'2018-10-20','Schwab Checking',633,'cash'),(128,'2018-10-20','BoA Savings',10150,'cash'),(129,'2018-10-21','Great Lakes Loans',2219,'liability'),(130,'2018-10-20','Cash',1514,'cash'),(131,'2018-10-25','BoA Savings',8777,'cash'),(132,'2018-10-25','Great Lakes Loans',2220,'liability'),(133,'2018-10-25','Schwab Beneficiary',250,'asset'),(134,'2018-10-25','Schwab Checking',5508,'cash'),(135,'2018-10-25','Schwab ROTH',16994,'asset'),(136,'2018-10-25','Cash',553,'cash'),(137,'2018-10-30','Great Lakes Loans',0,'liability'),(138,'2018-10-30','BoA Savings',8985,'cash'),(139,'2018-10-30','Schwab Checking',2753,'cash'),(140,'2018-10-30','Schwab Beneficiary',250,'asset'),(141,'2018-10-30','Schwab ROTH',16842,'asset'),(142,'2018-10-30','Cash',971,'cash'),(143,'2018-11-01','BoA Savings',8985,'cash'),(144,'2018-11-01','Schwab Beneficiary',250,'asset'),(145,'2018-11-01','Schwab ROTH',17282,'asset'),(146,'2018-11-01','Schwab Checking',2752,'cash'),(147,'2018-11-01','Cash',1109,'cash'),(148,'2018-11-01','Great Lakes Loans',0,'liability'),(149,'2018-11-05','BoA Savings',8985,'cash'),(150,'2018-11-05','Great Lakes Loans',0,'liability'),(151,'2018-11-05','Schwab Beneficiary',250,'asset'),(152,'2018-11-05','Schwab ROTH',17329,'asset'),(153,'2018-11-05','Schwab Checking',2678,'cash'),(154,'2018-11-05','Cash',1210,'cash'),(155,'2018-11-08','BoA Savings',10324,'cash'),(156,'2018-11-08','Schwab Beneficiary',250,'asset'),(157,'2018-11-08','Schwab Checking',2176,'cash'),(158,'2018-11-08','Schwab ROTH',17551,'asset'),(159,'2018-11-12','BoA Savings',10324,'cash'),(160,'2018-11-12','Cash',1185,'cash'),(161,'2018-11-12','Schwab Beneficiary',250,'asset'),(162,'2018-11-12','Schwab Checking',1817,'cash'),(163,'2018-11-12','Schwab ROTH',17129,'asset'),(164,'2018-11-21','Schwab Beneficiary',250,'asset'),(165,'2018-11-21','Schwab Checking',1671,'cash'),(166,'2018-11-21','Schwab ROTH',16962,'asset'),(167,'2018-11-21','BoA Savings',11644,'cash'),(168,'2018-11-21','Cash',1572,'cash');
/*!40000 ALTER TABLE `finance_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `finance_expenses`
--

DROP TABLE IF EXISTS `finance_expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `finance_expenses` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `name` tinytext NOT NULL,
  `type` enum('entertainment','educational','clothing','personal','health','food','giving','bill','auto','travel','fee','office','tax','gas','housing') NOT NULL,
  `subtype` tinytext,
  `amount` float unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=229 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `finance_expenses`
--

LOCK TABLES `finance_expenses` WRITE;
/*!40000 ALTER TABLE `finance_expenses` DISABLE KEYS */;
INSERT INTO `finance_expenses` (`id`, `date`, `name`, `type`, `subtype`, `amount`) VALUES (1,'2018-06-01','Quality Inn King Room','travel','accomodations',143.28),(2,'2018-06-02','Quality Inn King Room','travel',NULL,143.28),(3,'2018-06-03','Bryan & Ant Wedding Gift','giving',NULL,150),(4,'2018-06-03','Bryan & Ant Wedding Card','giving',NULL,4.89),(5,'2018-06-03','Pennsylvania Highway Toll','fee',NULL,1),(6,'2018-06-02','Tipping wedding staff','giving',NULL,17),(7,'2018-06-03','Work shirt','clothing',NULL,12),(8,'2018-06-03','Gas Fillup','gas',NULL,54),(9,'2018-06-04','Cazenovia Rent','housing',NULL,412.5),(10,'2018-06-04','Cazenovia Utilities (1/3rd)','bill',NULL,76),(11,'2018-06-04','Wegmans Groceries','food',NULL,33.18),(12,'2018-06-08','Gas Fillup','gas',NULL,51),(13,'2018-06-08','Tennis Balls','health',NULL,4.67),(14,'2018-06-10','Darts (didnt even play :( )','entertainment',NULL,2),(15,'2018-06-10','Jims Steakout','food',NULL,8.91),(16,'2018-06-10','Aldi Groceries','food',NULL,24.27),(17,'2018-06-10','Wegmans Groceries','food',NULL,63.64),(18,'2018-06-11','Flight to South Carolina','travel',NULL,290),(19,'2018-06-11','Housing South Carolina','travel',NULL,565),(20,'2018-06-12','Inflate Tires','auto',NULL,1),(21,'2018-06-17','Aldi Groceries','food',NULL,7.77),(22,'2018-06-17','Wegmans Groceries','food',NULL,34.2),(23,'2018-06-17','Fathers Day Card','giving',NULL,6.51),(24,'2018-06-17','Fathers Day Gift Card to Wales Hotel','giving',NULL,50),(25,'2018-06-18','Ricks Food (w/ Katie)','food',NULL,5.74),(26,'2018-06-19','Brakes, Rotors, Caliper Replaced by Hetz','auto',NULL,430),(27,'2018-06-19','Tipping Hetz','giving',NULL,20),(28,'2018-06-21','Spotify','entertainment',NULL,9.99),(29,'2018-06-22','Gas Fillup','gas',NULL,50),(30,'2018-06-22','Tipping Bartender','giving',NULL,5),(31,'2018-06-22','Darts & Pool w/ Dad','entertainment',NULL,3),(32,'2018-06-24','Aldi Groceries','food',NULL,22.06),(33,'2018-06-24','Wegmans Groceries','food',NULL,45.94),(34,'2018-06-28','Ricks Food (w/ Nick)','food',NULL,6.14),(35,'2018-06-29','Cover','entertainment','',3),(36,'2018-06-29','Zach Cover','giving','',3),(37,'2018-06-29','Goodbar Round of Drinks','entertainment','',12),(38,'2018-06-29','Tipping Bartender','giving','',2),(39,'2018-06-29','Darts','entertainment','',2),(40,'2018-06-29','Pizza','food','',5),(41,'2018-07-01','Aldi Groceries','food','',20.41),(42,'2018-07-01','Wegmans Groceries','food','',38.19),(43,'2018-07-01','Local Produce','food','',6),(44,'2018-07-01','Pizza Dough for Mom','food','',5),(45,'2018-07-03','McDonalds Breakfast','food','',4.35),(46,'2018-07-03','Food Truck Tuesday Food','food','',12),(47,'2018-07-03','Drink at Gastropub','entertainment','',5),(48,'2018-07-04','Tipping Bartender','giving','',2),(49,'2018-07-04','6-pack BUSCH','entertainment','',5.73),(50,'2018-07-04','Biotin & Razors','health','',55.33),(51,'2018-07-05','Ricks Burger','food','',12.19),(52,'2018-07-05','Cazenovia Rent','housing','',362.5),(53,'2018-07-05','Cazenovia Utilities (5/12ths)','bill','',59.75),(54,'2018-07-06','Gas Fillup','gas','',50.01),(56,'2018-06-27','Car Insurance - Geico','bill','',85.2),(57,'2018-07-07','Drink at Gastropub','entertainment','',5),(58,'2018-07-07','Tipping Bartender','giving','',2),(59,'2018-07-08','Wegmans Groceries','food','',25.91),(60,'2018-07-08','Aldi Groceries','food','',16.13),(61,'2018-07-06','Pizza','food','',12),(62,'2018-07-09','Mothers Day Card','giving','',7.6),(63,'2018-07-08','Mothers Day Linner','giving','',73),(64,'2018-07-13','Chipotle','food','',7.78),(65,'2018-07-15','Sonic Breakfast','food','',6.83),(66,'2018-07-15','Board Shorts','clothing','',5),(67,'2018-07-16','Parasailing','entertainment','',50),(68,'2018-07-16','Lexy Parasailing','giving','',25),(69,'2018-07-20','Moonshine (Myrtle)','entertainment','',25),(70,'2018-07-20','Hat (Myrtle)','clothing','',13),(71,'2018-07-22','Local Produce','food','',12),(72,'2018-07-22','Aldi Groceries','food','',35.9),(73,'2018-07-22','Wegmans Groceries','food','',61.44),(74,'2018-07-21','Spotify','entertainment','',9.99),(75,'2018-07-25','Gas','gas','',20),(76,'2018-07-28','Car Insurance - Geico','bill','',89.87),(77,'2018-07-30','Ricks Food (w/ Jenna)','food','',9),(78,'2018-07-31','Jennas portion of food','giving','',8),(79,'2018-07-28','McDonalds Breakfast','food','',4.35),(80,'2018-07-31','Aldi Groceries','food','',24.38),(81,'2018-07-29','Wegmans Groceries','food','',36.59),(82,'2018-07-29','McDonalds Breakfast','food','',4.35),(83,'2018-07-29','Gas','gas','',20),(84,'2018-08-03','Subway','food','',7.6),(85,'2018-08-07','Beer at REO Speedwagon concert for mom and dad','giving','',12),(86,'2018-08-09','Ricks Food (w/ Maddy)','food','',13),(87,'2018-08-12','Local Produce','food','',9),(88,'2018-08-05','Aldi Groceries','food','',16.99),(89,'2018-08-05','Wegmans Groceries','food','',31.14),(90,'2018-07-29','1st Month. Last Month. Deposit at 1988 Transit','housing','',1150),(91,'2018-08-12','Domador Food and Drink (w/ Eric and Alec)','food','',22),(92,'2018-08-03','Gas Fillup','gas','',44),(93,'2018-08-04','Drywall Anchors','housing','',1.72),(94,'2018-08-04','Dad Birthday Card','giving','',5.21),(95,'2018-08-05','Back of Door Hangers','housing','',10.86),(96,'2018-08-12','Gas Fillup','gas','',40),(97,'2018-08-12','Aldi Groceries','food','',15.28),(98,'2018-08-12','Wegmans Groceries','food','',29.57),(99,'2018-08-15','Chipotle','food','',8),(100,'2018-08-16','Darts','entertainment','',1),(101,'2018-08-17','Liquor','entertainment','',28.23),(102,'2018-08-17','Drinks on Allen','entertainment','',10),(103,'2018-08-17','Drinks for Eric and Kyle and Tip','giving','',10),(104,'2018-08-18','Ricks Blackened Steak Salad','food','',13),(105,'2018-08-19','Tipping Bartender (Dustin)','giving','',10),(106,'2018-08-19','Wegmans Groceries','food','',44.68),(107,'2018-08-21','Spotify','entertainment','',9.99),(108,'2018-08-21','Laundry','personal','',10),(109,'2018-08-21','Tipping Laundromat Owner','giving','',5),(110,'2018-08-22','Aldi Groceries','food','',15.77),(111,'2018-08-19','Gas Fillup','gas','',45),(112,'2018-08-26','Aldi Groceries','food','',18.83),(113,'2018-08-26','Wegmans Groceries','food','',24.34),(114,'2018-08-23','Ricks Burger','food','',12.19),(115,'2018-08-25','Domador Food and Tip (w/ Eric)','food','',11),(116,'2018-08-26','Biotin & Blender','personal','',37.32),(117,'2018-08-29','Angry Orchard Rose and Lemons and Limes','entertainment','',12.21),(118,'2018-08-29','Kumo','food','',17),(119,'2018-08-30','Subway','food','',7.6),(120,'2018-08-27','Car Insurance - Geico','bill','',84.87),(121,'2018-09-01','1988 Transit Utilities','bill','',73.63),(122,'2018-09-01','1988 Transit Rent','housing','',383.37),(123,'2018-09-02','Gas Fillup','gas','',52),(124,'2018-09-06','McDonalds Breakfast','food','',4.35),(125,'2018-09-06','Ricks Burger','food','',12.19),(126,'2018-09-09','Wegmans Groceries','food','',37.28),(127,'2018-09-09','Aldi Groceries','food','',22.61),(128,'2018-09-12','Wegmans Groceries','food','',37.67),(129,'2018-09-15','SOLO Cups','entertainment','',5.43),(130,'2018-09-17','Wegmans Groceries','food','',40.94),(131,'2018-09-20','Ricks Burger','food','',12.19),(132,'2018-09-01','Tim Hortons Breakfast','food','',4.35),(133,'2018-09-05','Wegmans Groceries','food','',78.89),(134,'2018-09-15','Wegmans Groceries','food','',14.1),(135,'2018-09-16','Ice and Water','food','',4.38),(136,'2018-09-16','Gas Fillup','gas','',44),(137,'2018-09-20','Subway','food','',7.6),(138,'2018-09-21','Spotify','entertainment','',9.99),(139,'2018-09-21','Vehicle Registration','auto','',60),(140,'2018-09-23','Aldi Groceries','food','',20.79),(141,'2018-09-23','Wegmans Groceries','food','',53.56),(142,'2018-09-25','Laundry','personal','',14),(143,'2018-09-25','Gas Fillup','gas','',48),(144,'2018-09-26','Kumo (w/ Mom)','food','',34.75),(145,'2018-09-27','Car Insurance - Geico','bill','',84.87),(146,'2018-09-27','Ricks Burger','food','',12.19),(147,'2018-09-28','Liquor & Wine','entertainment','',41.3),(148,'2018-09-30','Aldi Groceries','food','',22.83),(149,'2018-09-28','McDonalds Breakfast','food','',4.35),(150,'2018-09-30','Wegmans Groceries','food','',34.26),(151,'2018-09-30','Audible Book','entertainment','',14.36),(152,'2018-10-04','Subway','food','',7.6),(153,'2018-10-07','Gas Fillup','gas','',50),(154,'2018-10-07','Pens','personal','',5.44),(155,'2018-10-07','Socks','clothing','',6.29),(156,'2018-10-11','Ricks Burger','food','',12.19),(157,'2018-10-12','Wegmans Groceries','food','',15.65),(158,'2018-10-09','Wegmans Groceries','food','',24.91),(159,'2018-10-07','Wegmans Groceries','food','',47.78),(160,'2018-10-04','Wegmans Groceries','food','',30.69),(161,'2018-10-01','YMCA Membership','health','',21.5),(162,'2018-10-01','1988 Transit Rent','housing','',383.33),(163,'2018-10-01','1988 Transit Utilities','bill','',44.67),(164,'2018-10-16','Darts','entertainment','',1.25),(165,'2018-10-16','Rookies Salad','food','',15),(166,'2018-10-16','Burts Bees and Lotion','health','',5.41),(167,'2018-10-19','Chipotle','food','',8.27),(168,'2018-10-20','Halloween Costume & Batteries','entertainment','',22.1),(169,'2018-10-19','Tipping Valvoline','giving','',10),(170,'2018-10-17','Wegmans Groceries','food','',21.47),(171,'2018-10-17','YMCA Membership','health','',43),(172,'2018-10-18','Gas Fillup','gas','',50),(173,'2018-10-19','Oil Change','auto','',39.14),(174,'2018-10-21','Spotify','entertainment','',9.99),(175,'2018-10-21','Aldi Groceries','food','',23.57),(176,'2018-10-21','Wegmans Groceries','food','',72.79),(177,'2018-10-21','LRW Roycroft Meal (w/ Mom)','food','',25.21),(178,'2018-10-21','LRW Tip','giving','',10),(179,'2018-10-25','Ricks Burger','food','',12.19),(180,'2018-10-26','Rocket League (PS4)','entertainment','',19.99),(181,'2018-10-26','Car Insurance - Geico','auto','',84.87),(182,'2018-10-28','Aldi Groceries','food','',22.09),(183,'2018-10-28','Wegmans Groceries','food','',51.24),(184,'2018-11-03','Ohio State Game Tickets','entertainment','',40),(185,'2018-11-03','Bryan & Ant Food and Drink','entertainment','',20),(186,'2018-11-03','Titos and Water & Tip','entertainment','',6),(187,'2018-11-03','Beer at Brewery and tip','entertainment','',6),(188,'2018-11-03','Food, Drink & Tip at Food Hall','entertainment','',45),(189,'2018-11-03','Nachos at OSU game','food','',9),(190,'2018-11-02','Chipotle','food','',6.85),(191,'2018-11-04','Brunch','food','',13),(192,'2018-11-04','Paying Fink for Gas and Driving','gas','',40),(193,'2018-11-03','Titos and Water & Tip','entertainment','',6),(194,'2018-10-21','McDonalds Breakfast','food','',4.35),(195,'2018-10-27','Gas Fillup','gas','',49.5),(196,'2018-10-27','PS4','entertainment','',292.54),(197,'2018-10-28','Audible Subscription','entertainment','',14.95),(198,'2018-11-02','Inflate Tires','auto','',1.5),(199,'2018-11-07','Gas Fillup','gas','',48.01),(200,'2018-11-06','Subway','food','',7.6),(201,'2018-11-07','Chipotle','food','',7.78),(202,'2018-11-06','Tim Hortons','food','',5.34),(203,'2018-11-07','Hulu Subscription (Forgot to cancel)','entertainment','',22.98),(204,'2018-11-01','1988 Transit Rent','housing','',383.33),(205,'2018-11-01','1988 Transit Utilities','bill','',34.67),(206,'2018-11-09','Chinese Food Alec and I','food','',20),(207,'2018-09-01','1988 Transit Utilities (Back-Payment)','bill','',27.33),(208,'2018-10-01','1988 Transit Utilities (Back-Payment)','bill','',27.33),(209,'2018-11-01','1988 Transit Utilities (Back-Payment)','bill','',27.33),(210,'2018-11-09','Concourse Club Cover (Mine & Alec)','entertainment','',10),(211,'2018-11-10','Dalessandros Philly Cheesesteak (split w/ Alec)','food','',10),(212,'2018-11-11','Tolls','fee','',11.7),(213,'2018-11-11','Tolls','fee','',5.7),(214,'2018-11-10','Pho (Vietnamese Soup w/ Alec) & Tip','food','',20),(215,'2018-11-11','Gas Fillup','gas','',48.01),(216,'2018-11-11','Pizza Hut','food','',5.79),(217,'2018-11-12','Aldi Groceries','food','',34.67),(218,'2018-11-12','Wegmans Groceries','food','',41.39),(219,'2018-11-09','Wawa Sandwich','food','',5.61),(220,'2018-11-10','Liquor','entertainment','',31.3),(221,'2018-11-15','Ricks Burger','food','',12.19),(222,'2018-11-16','Two for one drinks and tip at Yings','entertainment','',6),(223,'2018-11-13','Inflate Tires','auto','',1.5),(224,'2018-11-14','Gas Fillup','gas','',48),(225,'2018-11-17','YMCA Membership','health','',43),(226,'2018-11-16','McDonalds Breakfast','food','',4.35),(227,'2018-11-18','Aldi Groceries','food','',20.16),(228,'2018-11-18','Wegmans Groceries','food','',42.92);
/*!40000 ALTER TABLE `finance_expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `finance_ricks_shifts`
--

DROP TABLE IF EXISTS `finance_ricks_shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `finance_ricks_shifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `type` tinytext,
  `hours` float unsigned NOT NULL,
  `tips` smallint(5) unsigned NOT NULL,
  `stress` tinyint(3) unsigned DEFAULT NULL,
  `enjoyment` tinyint(3) unsigned DEFAULT NULL,
  `description` tinytext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `finance_ricks_shifts`
--

LOCK TABLES `finance_ricks_shifts` WRITE;
/*!40000 ALTER TABLE `finance_ricks_shifts` DISABLE KEYS */;
INSERT INTO `finance_ricks_shifts` (`id`, `date`, `type`, `hours`, `tips`, `stress`, `enjoyment`, `description`) VALUES (1,'2018-06-07','pm',5.54,150,NULL,NULL,NULL),(2,'2018-06-09','am',5.17,105,NULL,NULL,NULL),(3,'2018-06-09','pm',6.45,238,NULL,NULL,NULL),(4,'2018-06-11','pm',5.85,165,NULL,NULL,NULL),(5,'2018-06-14','pm',5.34,190,NULL,NULL,NULL),(6,'2018-06-16','am',4.67,60,NULL,NULL,NULL),(7,'2018-06-16','pm',6.14,365,NULL,NULL,NULL),(8,'2018-06-18','pm',4.94,72,NULL,NULL,NULL),(9,'2018-06-21','pm',5.93,275,NULL,NULL,NULL),(10,'2018-06-23','am',4.58,110,NULL,NULL,NULL),(11,'2018-06-23','pm',6.17,260,NULL,NULL,NULL),(12,'2018-06-25','pm',6.52,183,NULL,NULL,NULL),(13,'2018-06-28','pm',4.76,150,NULL,NULL,NULL),(14,'2018-06-30','am',4.53,95,NULL,NULL,NULL),(15,'2018-06-30','pm',6.09,178,NULL,NULL,NULL),(16,'2018-07-05','pm',5.8,287,NULL,NULL,NULL),(17,'2018-07-07','am',4.92,119,NULL,NULL,NULL),(18,'2018-07-07','pm',6.12,236,NULL,NULL,NULL),(19,'2018-07-09','pm',4.56,150,NULL,NULL,NULL),(20,'2018-07-12','pm',6.12,305,NULL,NULL,NULL),(21,'2018-07-23','pm',4.6,127,NULL,NULL,NULL),(22,'2018-07-26','pm',4.11,120,NULL,NULL,NULL),(25,'2018-07-28','am',4.5,109,NULL,NULL,NULL),(26,'2018-07-28','pm',6.28,159,NULL,NULL,NULL),(27,'2018-07-30','pm',5.25,147,NULL,NULL,NULL),(28,'2018-08-02','pm',6.38,206,NULL,NULL,NULL),(29,'2018-08-04','am',3.31,34,NULL,NULL,NULL),(30,'2018-08-04','pm',5.1,136,NULL,NULL,NULL),(31,'2018-08-06','pm',5.48,185,NULL,NULL,NULL),(32,'2018-08-09','pm',5.25,135,NULL,NULL,NULL),(33,'2018-08-11','am',4.76,104,NULL,NULL,NULL),(34,'2018-08-11','pm',5.39,163,NULL,NULL,NULL),(35,'2018-08-13','pm',5.19,179,NULL,NULL,NULL),(36,'2018-08-16','pm',5.5,256,NULL,NULL,NULL),(37,'2018-08-18','am',3.89,65,NULL,NULL,NULL),(38,'2018-08-18','pm',5.39,168,NULL,NULL,NULL),(39,'2018-08-20','pm',4.51,121,NULL,NULL,NULL),(40,'2018-08-23','pm',5.44,209,NULL,NULL,NULL),(41,'2018-08-25','pm',5.9,225,NULL,NULL,NULL),(42,'2018-08-27','pm',4.36,147,NULL,NULL,NULL),(43,'2018-08-30','pm',6.69,342,NULL,NULL,NULL),(44,'2018-09-06','pm',5.9,157,NULL,NULL,NULL),(45,'2018-09-08','am',4.16,75,NULL,NULL,NULL),(46,'2018-09-08','pm',6.55,206,NULL,NULL,NULL),(47,'2018-09-10','pm',4.88,160,NULL,NULL,NULL),(48,'2018-09-13','pm',5.59,120,NULL,NULL,NULL),(49,'2018-09-15','am',4.75,88,NULL,NULL,NULL),(50,'2018-09-15','pm',6.14,350,NULL,NULL,NULL),(51,'2018-09-17','pm',4.17,94,NULL,NULL,NULL),(52,'2018-09-20','pm',5.05,205,NULL,NULL,NULL),(53,'2018-09-22','am',4.53,98,NULL,NULL,NULL),(54,'2018-09-22','pm',5.8,215,NULL,NULL,NULL),(55,'2018-09-24','pm',4.66,125,NULL,NULL,NULL),(56,'2018-09-27','pm',5.6,145,NULL,NULL,NULL),(57,'2018-09-28','pm',3.57,152,NULL,NULL,NULL),(58,'2018-09-29','am',5.22,130,NULL,NULL,NULL),(59,'2018-09-29','pm',5.81,290,NULL,NULL,NULL),(60,'2018-10-01','pm',4.07,101,NULL,NULL,NULL),(61,'2018-10-02','pm',5.17,95,NULL,NULL,NULL),(62,'2018-10-06','am',4.89,75,NULL,NULL,NULL),(63,'2018-10-06','pm',6.07,440,NULL,NULL,NULL),(64,'2018-10-08','pm',6.05,217,NULL,NULL,NULL),(65,'2018-10-11','pm',5.86,190,NULL,NULL,NULL),(66,'2018-10-13','am',4.97,105,NULL,NULL,NULL),(67,'2018-10-13','pm',6.37,240,NULL,NULL,NULL),(68,'2018-10-15','pm',4.37,96,NULL,NULL,NULL),(69,'2018-10-17','pm',4.36,180,NULL,NULL,NULL),(70,'2018-10-20','am',4.33,88,NULL,NULL,NULL),(71,'2018-10-20','pm',6.18,192,NULL,NULL,NULL),(72,'2018-10-23','pm',5.31,240,NULL,NULL,NULL),(73,'2018-10-25','pm',5.07,151,NULL,NULL,NULL),(74,'2018-10-27','am',4.05,80,NULL,NULL,NULL),(75,'2018-10-27','pm',5.28,151,NULL,NULL,NULL),(76,'2018-10-29','pm',4.34,105,NULL,NULL,NULL),(77,'2018-10-30','pm',4.06,82,NULL,NULL,NULL),(78,'2018-11-01','pm',5.07,138,NULL,NULL,NULL),(79,'2018-11-05','pm',4.72,220,2,7,'Pharmaceutical in Banquet Room. Worked with a solid crew. '),(80,'2018-11-12','pm',3.86,70,NULL,NULL,NULL),(81,'2018-11-15','pm',6.27,169,NULL,NULL,NULL),(82,'2018-11-17','am',2.85,56,NULL,NULL,NULL),(83,'2018-11-17','pm',5.69,168,NULL,NULL,NULL),(84,'2018-11-19','pm',3.3,23,2,2,'Section 205. Extremely Slow. Kevin had allergic reaction. Not pleased with Jennas Divvying up of tables.');
/*!40000 ALTER TABLE `finance_ricks_shifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `finance_seal_income`
--

DROP TABLE IF EXISTS `finance_seal_income`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `finance_seal_income` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `type` tinytext NOT NULL,
  `amount` float unsigned NOT NULL,
  `start_payperiod` date DEFAULT NULL,
  `end_payperiod` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `finance_seal_income`
--

LOCK TABLES `finance_seal_income` WRITE;
/*!40000 ALTER TABLE `finance_seal_income` DISABLE KEYS */;
INSERT INTO `finance_seal_income` (`id`, `date`, `type`, `amount`, `start_payperiod`, `end_payperiod`) VALUES (1,'2018-06-06','check',692.31,'2018-05-29','2018-06-02'),(2,'2018-06-20','check',1730.77,'2018-06-03','2018-06-16'),(3,'2018-07-04','check',1730.77,'2018-06-17','2018-06-30'),(4,'2018-07-18','check',1730.77,'2018-07-01','2018-07-14'),(5,'2018-08-01','check',927.88,'2018-07-15','2018-07-28'),(6,'2018-08-15','check',1879.81,'2018-07-29','2018-08-11'),(7,'2018-08-29','check',1730.77,'2018-08-12','2018-08-25'),(8,'2018-09-12','check',1831.73,'2018-08-26','2018-09-08'),(9,'2018-09-12','bonus',800,NULL,NULL),(10,'2018-09-26','check',1831.73,'2018-09-09','2018-09-22'),(11,'2018-10-10','check',1831.73,'2018-09-23','2018-10-06'),(12,'2018-10-24','check',1831.73,'2018-10-07','2018-10-20'),(13,'2018-11-08','check',1831.73,'2018-10-21','2018-11-03'),(14,'2018-11-21','check',1831.73,'2018-11-04','2018-11-17');
/*!40000 ALTER TABLE `finance_seal_income` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `finance_seal_shifts`
--

DROP TABLE IF EXISTS `finance_seal_shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `finance_seal_shifts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `arrival_time` time NOT NULL,
  `departure_time` time NOT NULL,
  `strain` tinyint(3) unsigned DEFAULT NULL,
  `feedback` tinyint(3) unsigned DEFAULT NULL,
  `stress` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `finance_seal_shifts`
--

LOCK TABLES `finance_seal_shifts` WRITE;
/*!40000 ALTER TABLE `finance_seal_shifts` DISABLE KEYS */;
INSERT INTO `finance_seal_shifts` (`id`, `date`, `arrival_time`, `departure_time`, `strain`, `feedback`, `stress`) VALUES (1,'2018-05-29','08:25:00','17:05:00',8,7,3),(2,'2018-05-30','08:28:00','17:03:00',8,6,4),(3,'2018-05-31','07:27:00','16:11:00',5,5,5),(4,'2018-06-01','08:26:00','17:09:00',8,7,4),(5,'2018-06-04','07:26:00','16:11:00',7,6,3),(6,'2018-06-05','08:29:00','17:14:00',7,5,3),(7,'2018-06-06','08:28:00','17:17:00',8,6,3),(8,'2018-06-07','07:31:00','16:08:00',8,5,3),(9,'2018-06-08','08:31:00','17:15:00',6,6,2),(10,'2018-06-11','07:32:00','16:24:00',5,4,3),(11,'2018-06-12','08:32:00','17:02:00',5,7,3),(12,'2018-06-13','08:33:00','17:08:00',7,6,2),(13,'2018-06-14','07:36:00','16:05:00',5,5,2),(14,'2018-06-15','08:37:00','17:09:00',4,3,2),(15,'2018-06-18','07:37:00','16:08:00',8,3,4),(16,'2018-06-19','08:34:00','17:10:00',6,5,3),(17,'2018-06-20','08:32:00','17:09:00',8,4,4),(18,'2018-06-21','07:33:00','16:06:00',7,6,3),(19,'2018-06-22','08:33:00','17:09:00',7,6,1),(20,'2018-06-25','07:33:00','16:04:00',8,6,2),(21,'2018-06-26','08:35:00','17:11:00',8,6,5),(22,'2018-06-27','08:33:00','17:16:00',8,5,3),(23,'2018-06-28','07:34:00','16:05:00',7,4,3),(24,'2018-06-29','08:33:00','17:14:00',6,6,2),(25,'2018-07-02','08:34:00','17:11:00',6,4,4),(26,'2018-07-03','08:31:00','16:11:00',6,4,3),(27,'2018-07-05','07:34:00','16:07:00',6,6,2),(28,'2018-07-06','08:36:00','17:03:00',7,6,2),(29,'2018-07-09','07:38:00','16:08:00',4,6,2),(30,'2018-07-10','08:31:00','17:08:00',5,6,3),(31,'2018-07-11','08:31:00','17:58:00',4,4,4),(32,'2018-07-12','07:32:00','16:04:00',6,4,2),(33,'2018-07-13','08:33:00','17:06:00',4,4,2),(34,'2018-07-23','07:34:00','16:06:00',8,4,2),(35,'2018-07-24','08:33:00','17:06:00',8,6,3),(36,'2018-07-25','08:34:00','15:08:00',8,6,3),(37,'2018-07-26','07:33:00','16:03:00',7,6,2),(38,'2018-07-27','08:29:00','18:08:00',9,7,2),(39,'2018-07-30','07:32:00','16:02:00',6,4,3),(40,'2018-07-31','08:32:00','17:06:00',6,8,2),(41,'2018-08-01','08:34:00','17:10:00',8,6,2),(42,'2018-08-02','07:46:00','16:01:00',6,4,2),(43,'2018-08-03','08:33:00','17:03:00',6,5,2),(44,'2018-08-06','07:36:00','16:04:00',5,4,2),(45,'2018-08-07','08:46:00','17:06:00',6,5,3),(46,'2018-08-08','08:32:00','17:07:00',8,6,4),(47,'2018-08-09','07:32:00','16:01:00',8,5,3),(48,'2018-08-10','08:36:00','17:07:00',8,7,2),(49,'2018-08-13','07:37:00','16:01:00',5,8,2),(50,'2018-08-14','08:28:00','17:05:00',7,7,3),(51,'2018-08-15','08:31:00','17:06:00',8,7,5),(52,'2018-08-16','07:36:00','16:02:00',4,6,3),(53,'2018-08-17','08:33:00','17:02:00',7,5,4),(54,'2018-08-20','07:37:00','16:01:00',6,7,3),(55,'2018-08-21','08:33:00','17:08:00',8,6,5),(56,'2018-08-22','08:30:00','17:10:00',8,5,5),(57,'2018-08-23','07:35:00','16:07:00',7,6,4),(58,'2018-08-24','08:34:00','17:47:00',7,7,5),(59,'2018-08-27','07:32:00','16:18:00',6,6,5),(60,'2018-08-28','08:31:00','20:48:00',8,7,6),(61,'2018-08-29','08:27:00','19:35:00',8,6,6),(62,'2018-08-30','07:29:00','16:07:00',8,7,7),(63,'2018-08-31','11:22:00','23:59:00',7,6,5),(64,'2018-09-01','08:50:00','20:30:00',8,6,5),(65,'2018-09-02','09:00:00','19:48:00',6,7,5),(66,'2018-09-03','05:00:00','23:59:00',7,7,7),(67,'2018-09-04','12:30:00','22:00:00',8,5,6),(68,'2018-09-06','08:00:00','16:02:00',6,5,6),(69,'2018-09-07','08:34:00','17:45:00',6,7,4),(70,'2018-09-05','08:42:00','19:00:00',7,6,6),(71,'2018-09-10','07:41:00','16:20:00',6,7,6),(72,'2018-09-11','08:38:00','17:23:00',7,7,6),(73,'2018-09-12','08:35:00','17:20:00',6,6,5),(74,'2018-09-13','08:20:00','16:05:00',7,7,7),(75,'2018-09-14','08:36:00','17:08:00',6,7,5),(76,'2018-09-18','08:34:00','17:13:00',6,6,3),(77,'2018-09-19','08:34:00','17:07:00',6,6,3),(78,'2018-09-20','07:49:00','16:01:00',6,6,4),(79,'2018-09-21','08:35:00','17:00:00',5,5,3),(80,'2018-09-24','07:43:00','16:11:00',5,5,5),(81,'2018-09-25','08:33:00','17:04:00',6,5,4),(82,'2018-09-27','07:44:00','16:03:00',6,5,4),(83,'2018-09-26','08:35:00','17:04:00',6,6,4),(84,'2018-09-28','08:20:00','16:22:00',5,7,3),(85,'2018-10-01','07:46:00','16:03:00',6,6,3),(86,'2018-10-02','07:44:00','16:03:00',5,5,3),(87,'2018-10-04','08:37:00','17:15:00',6,4,5),(88,'2018-10-03','08:35:00','17:06:00',6,5,4),(89,'2018-10-05','08:36:00','17:05:00',8,6,6),(90,'2018-10-08','07:43:00','16:04:00',6,6,3),(91,'2018-10-09','10:34:00','19:03:00',6,5,4),(92,'2018-10-11','07:44:00','16:00:00',5,5,3),(93,'2018-10-10','08:33:00','17:00:00',6,5,3),(94,'2018-10-12','08:34:00','17:05:00',6,5,3),(95,'2018-10-15','07:38:00','16:03:00',7,6,3),(96,'2018-10-16','08:42:00','17:09:00',7,7,3),(97,'2018-10-17','08:43:00','16:06:00',6,7,3),(98,'2018-10-18','08:36:00','18:04:00',6,6,3),(99,'2018-10-19','08:39:00','17:09:00',6,7,2),(100,'2018-10-22','08:37:00','17:11:00',6,5,3),(101,'2018-10-23','07:48:00','16:04:00',7,6,4),(102,'2018-10-24','10:32:00','19:01:00',6,6,4),(103,'2018-10-25','07:46:00','16:04:00',6,5,4),(104,'2018-10-26','08:36:00','17:12:00',6,6,2),(105,'2018-10-29','07:38:00','16:04:00',6,5,3),(106,'2018-10-30','07:39:00','16:02:00',7,7,3),(107,'2018-10-31','08:39:00','17:28:00',5,5,2),(108,'2018-11-01','07:41:00','16:07:00',7,8,5),(109,'2018-11-02','08:39:00','15:08:00',7,7,2),(110,'2018-11-05','07:39:00','16:07:00',7,7,3),(111,'2018-11-06','08:38:00','18:11:00',6,6,2),(112,'2018-11-07','08:39:00','17:10:00',6,7,3),(113,'2018-11-08','08:21:00','13:03:00',6,3,3),(114,'2018-11-09','08:00:00','12:38:00',6,6,3),(115,'2018-11-13','08:42:00','17:11:00',6,7,2),(116,'2018-11-14','08:42:00','17:04:00',8,3,6),(117,'2018-11-15','07:42:00','16:04:00',7,3,2),(118,'2018-11-16','11:07:00','17:12:00',6,7,3),(119,'2018-11-19','07:41:00','16:04:00',6,7,4),(120,'2018-11-20','08:41:00','17:20:00',7,7,3),(121,'2018-11-21','08:36:00','16:03:00',6,7,2);
/*!40000 ALTER TABLE `finance_seal_shifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fitness_best_lifts`
--

DROP TABLE IF EXISTS `fitness_best_lifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fitness_best_lifts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `exercise_id` smallint(5) unsigned NOT NULL,
  `workout_structure_id` smallint(5) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  `total_reps` float unsigned NOT NULL,
  `lift_id` mediumint(8) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fitness_best_lifts`
--

LOCK TABLES `fitness_best_lifts` WRITE;
/*!40000 ALTER TABLE `fitness_best_lifts` DISABLE KEYS */;
INSERT INTO `fitness_best_lifts` (`id`, `exercise_id`, `workout_structure_id`, `weight`, `total_reps`, `lift_id`) VALUES (1,1,1,107.5,28,129),(2,1,2,107.5,25,178),(3,2,1,107.5,30,135),(4,3,1,60,27,141),(5,3,2,67.5,25,209),(6,3,4,55,42,147),(7,4,1,55,29,130),(8,5,1,22.5,30,133),(9,6,1,17.5,26,127),(10,6,2,20,21,207),(11,6,4,20,18,213),(12,7,1,0,26,90),(13,8,1,27.5,26,128),(14,8,2,35,25,254),(15,9,1,0,19,120),(16,10,1,32.5,30,143),(17,11,1,2.5,29,119),(18,12,1,37.5,29,132),(19,13,1,37.5,32,131),(20,14,1,10,30,134),(21,14,2,20,25,244),(22,16,1,0,29,146),(23,17,1,0,30,54),(24,18,1,0,27,111),(25,18,2,0,25,187),(26,19,2,100,25,200),(27,20,2,115,21,169),(28,21,2,80,25,157),(29,22,2,30,25,158),(30,23,2,190,23,210),(31,23,3,205,1,211),(32,24,2,65,25,243),(33,24,9,45,52,197),(34,25,2,65,25,201),(35,26,2,45,22,162),(36,27,2,70,25,241),(37,29,2,120,25,167),(38,30,2,40,22,206),(39,31,2,170,25,248),(40,32,2,40,25,190),(41,33,2,155,25,247),(42,34,2,125,25,239),(43,35,2,75,25,194),(44,36,9,45,53,195),(45,37,4,90,26,214),(46,14,4,0,100,227),(47,17,4,0,55,230),(48,11,4,0,30,231),(49,36,1,62.5,25,232),(50,29,4,120,22,234),(51,49,4,155,10,235),(52,50,2,120,25,249),(53,13,2,40,25,238),(54,48,3,0,65,245),(55,21,1,80,18,246),(56,51,4,80,9,250),(57,52,2,80,25,252),(58,49,2,155,24,253);
/*!40000 ALTER TABLE `fitness_best_lifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fitness_circumferences`
--

DROP TABLE IF EXISTS `fitness_circumferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fitness_circumferences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `description` text NOT NULL,
  `ideal` float unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fitness_circumferences`
--

LOCK TABLES `fitness_circumferences` WRITE;
/*!40000 ALTER TABLE `fitness_circumferences` DISABLE KEYS */;
INSERT INTO `fitness_circumferences` (`id`, `name`, `description`, `ideal`) VALUES (1,'neck','Circumference around the adam\'s apple directly around the neck.',15),(2,'shoulders','Circumference around the widest part of the shoulders. Lightly exhaled breath. Standing. Shoulders slightly brought back.',48),(3,'chest','Circumference around the widest part of the chest. Typically directly under the armpits. Lightly exhaled breath. Standing. Shoulders slightly brought back.',42.25),(4,'upper arms','Circumference around the widest part of the upper arm. Standing. Arms out towards the side at a 45 degree angle. Measurements should be the mean of both the left and the right side.',15),(5,'lower arms','Circumference around the widest part of the lower arm. Standing. Arms out towards the side at a 45 degree angle. Measurements should be the mean of both the left and the right side.',12.25),(6,'waist','Circumference around the slimmest part of the waist. Lightly exhaled breath. Standing. Shoulders slightly brought back.',29.5),(7,'hips','Circumference around the widest part of the hips. Lightly exhaled breath. Standing. Shoulders slightly brought back. Feet shoulder width apart.',36),(8,'thigh','Circumference around the widest part of the thigh. Standing. Feet shoulder width apart. Should be the mean of both the left and right sides.',22.5),(9,'calf','Circumference around the widest part of the calf. Standing. Feet shoulder width apart. Should be the mean of both the left and right sides.',14.5);
/*!40000 ALTER TABLE `fitness_circumferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fitness_cycles`
--

DROP TABLE IF EXISTS `fitness_cycles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fitness_cycles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `workout_structure_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fitness_cycles`
--

LOCK TABLES `fitness_cycles` WRITE;
/*!40000 ALTER TABLE `fitness_cycles` DISABLE KEYS */;
INSERT INTO `fitness_cycles` (`id`, `start_date`, `end_date`, `workout_structure_id`) VALUES (1,'2018-06-18','2018-10-03',1),(2,'2018-10-04','2018-11-30',2);
/*!40000 ALTER TABLE `fitness_cycles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fitness_equipment`
--

DROP TABLE IF EXISTS `fitness_equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fitness_equipment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fitness_equipment`
--

LOCK TABLES `fitness_equipment` WRITE;
/*!40000 ALTER TABLE `fitness_equipment` DISABLE KEYS */;
INSERT INTO `fitness_equipment` (`id`, `name`) VALUES (1,'Dumbbell(s)'),(2,'EZ Curl Bar'),(3,'BOSU Ball'),(4,'Bodyweight'),(5,'Machine/Cable'),(6,'Barbell'),(7,'T-Bar'),(8,'Bench'),(9,'Pullup Bar'),(10,'Captain\'s Chair'),(11,'Squat Rack'),(12,'Fat Grips');
/*!40000 ALTER TABLE `fitness_equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fitness_exercises`
--

DROP TABLE IF EXISTS `fitness_exercises`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fitness_exercises` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `reference_url` tinytext,
  `description` text,
  `rating` float unsigned DEFAULT NULL COMMENT 'My rating of this exercise',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fitness_exercises`
--

LOCK TABLES `fitness_exercises` WRITE;
/*!40000 ALTER TABLE `fitness_exercises` DISABLE KEYS */;
INSERT INTO `fitness_exercises` (`id`, `name`, `reference_url`, `description`, `rating`) VALUES (1,'Standing EZ Shrugs',NULL,'Feet shoulder width apart. Adjust grip slightly each set. Avoid using biceps. Lift bar up to waistband.',NULL),(2,'Standing EZ Calf Raises',NULL,'',NULL),(3,'Standing EZ Curls','https://www.bodybuilding.com/exercises/ez-bar-curl','Feet shoulder width apart. Adjust grip slightly each set. Avoid using back. It can be beneficial to slightly lean over to minimize back usage.',NULL),(4,'DB Bench Press','https://www.bodybuilding.com/exercises/dumbbell-bench-press',NULL,NULL),(5,'Standing DB Overhead Extensions',NULL,'Feet shoulder width apart. One DB in each hand. Move DB from directly over head (arm straight) to about a 90 degree bend.',NULL),(6,'Standing DB Side Lateral Raises',NULL,'Feet shoulder width apart. Do not raise DBs above 90 degrees.',NULL),(7,'Myatotic Crunches',NULL,'Butt should be no more than 3 inches from ground. Biceps should be pressed against (or behind) ears. Back should be extended on the down portion with hands reaching away from torso.',NULL),(8,'Palms-Up Dumbbell Wrist Curl Over A Bench',NULL,'Kneeling facing the bench.',NULL),(9,'Pullups',NULL,NULL,NULL),(10,'DB Inclined Row',NULL,NULL,NULL),(11,'Supermans','https://www.bodybuilding.com/exercises/superman',NULL,NULL),(12,'Dumbbell Squats','https://www.bodybuilding.com/exercises/dumbbell-squat','Standing. Feet shoulder width apart. Each arm has one DB.',NULL),(13,'Stiff-Legged Dumbbell Deadlift','https://www.bodybuilding.com/exercises/stiff-legged-dumbbell-deadlift','Standing. Feet shoulder width apart. Each arm has one DB.',NULL),(14,'Butt Lifts','https://www.bodybuilding.com/exercises/butt-lift-bridge','Lying down. Cadence should be relatively fast up and down with a slight hold at the top.',NULL),(15,'Hanging Side Leg Lifts','','Hanging in open area. Move legs from one side to the other. Each rep should be a move to both sides.',NULL),(16,'Bodyweight Dips','https://www.bodybuilding.com/exercises/bench-dips','Platform for hands should be at least 18 inches off ground. Feet should be either at ground level or slightly raised.',NULL),(17,'Cross Body Crunches','https://www.bodybuilding.com/exercises/cross-body-crunch','Each set should result in one twist in each direction. For example, with a 4s cadence, 2s per side.',NULL),(18,'Declined Oblique Crunches','https://www.bodybuilding.com/exercises/decline-oblique-crunch','This should be performed unilaterally. For example, with workout structure 1, 10 reps twisting to the left @ 4s then 10 reps twisting to the right @ 4s. Twisting to the opposite side normally would count as rest but because this uses abdominal muscles too, more rest is necessary. Unfortunately, not ideal for our purposes but good strain on abs and obliques without straining back.',NULL),(19,'Machine Lateral Raises','https://www.bodybuilding.com/exercises/machine-lateral-raise','',NULL),(20,'Machine Reverse Flyes','https://www.bodybuilding.com/exercises/reverse-machine-flyes','',NULL),(21,'Machine Preacher Curls','','Avoid using low back to help biceps.',NULL),(22,'Seated Inclined Cable Flyes','https://www.bodybuilding.com/exercises/incline-cable-flye',NULL,NULL),(23,'Barbell Bench Press','https://www.bodybuilding.com/exercises/barbell-bench-press-medium-grip','Use foam block to mitigate tension on elbows from bringing bar too low.',NULL),(24,'Tricep Cable Pushdowns','https://www.bodybuilding.com/exercises/triceps-pushdown-rope-attachment','V-Bar attachment and rope attachments are favorites.',NULL),(25,'DB Shrugs','https://www.bodybuilding.com/exercises/dumbbell-shrug','Feet shoulder width apart.',NULL),(26,'EZ Overhand Forearm Curls',NULL,'Palms facing down. Using preacher curl sett-up.',NULL),(27,'Dumbbell Calf Raises','https://www.bodybuilding.com/exercises/standing-dumbbell-calf-raise','Feet slightly less than shoulder width apart. Ideally with toes on a 1 inch platform with heals hanging off.',NULL),(28,'Hanging Straight Leg Lifts','','Hanging in open area. Move legs straight out with toes pointed forward; no bend in knees.',NULL),(29,'Seated Cable Row','https://www.bodybuilding.com/exercises/seated-cable-rows','During last rest second pull bar back so that arms are fully extended and back is straight. Then each rep should just focus on moving arms.',NULL),(30,'Standing DB Hammer Curls','','Feet shoulder width apart. Avoid using back. It can be beneficial to slightly lean over to minimize back usage.',NULL),(31,'Machine Lat Pulldowns','https://www.bodybuilding.com/exercises/wide-grip-lat-pulldown','Adjust grip slightly each set.',NULL),(32,'Seated DB Overhead Press','https://www.bodybuilding.com/exercises/dumbbell-shoulder-press','',NULL),(33,'Barbell Squats','https://www.bodybuilding.com/exercises/barbell-full-squat','Feet shoulder width apart. Ensure knees dont extend beyond toes.',NULL),(34,'Barbell Deadlift','https://www.bodybuilding.com/exercises/barbell-deadlift','Feet shoulder width apart. Graze bar along legs during ascent (and descent.)',NULL),(35,'Fat Grip Bent Rows','https://www.bodybuilding.com/exercises/bent-over-barbell-row','Feet shoulder width apart. Pinch shoulders back throughout lift.',NULL),(36,'Standing Cable Curls','','Avoid using low back to help biceps.',NULL),(37,'T-Bar Row',NULL,'Straddle T-Bar facing plates. Lift up similar to deadlift with grip pinky to index finger. Each rep should focus on scapula pinching together.',NULL),(43,'Pushups','https://www.bodybuilding.com/exercises/pushups',NULL,NULL),(44,'Close Pushups',NULL,NULL,NULL),(47,'Air Squats',NULL,NULL,NULL),(48,'Side Planks',NULL,NULL,NULL),(49,'Smith Machine Shrugs',NULL,NULL,NULL),(50,'Machine Overhead Press',NULL,NULL,NULL),(51,'Barbell Curl',NULL,NULL,NULL),(52,'Machine Arm Extensions',NULL,NULL,NULL);
/*!40000 ALTER TABLE `fitness_exercises` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fitness_ideal_recovery_times`
--

DROP TABLE IF EXISTS `fitness_ideal_recovery_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fitness_ideal_recovery_times` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `muscle_id` int(10) unsigned NOT NULL,
  `workout_structure_id` int(10) unsigned NOT NULL,
  `ideal_recovery` float unsigned NOT NULL COMMENT 'In hours',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fitness_ideal_recovery_times`
--

LOCK TABLES `fitness_ideal_recovery_times` WRITE;
/*!40000 ALTER TABLE `fitness_ideal_recovery_times` DISABLE KEYS */;
INSERT INTO `fitness_ideal_recovery_times` (`id`, `muscle_id`, `workout_structure_id`, `ideal_recovery`) VALUES (1,1,1,96),(2,2,1,96),(3,3,1,96),(4,4,1,96),(5,5,1,96),(6,6,1,96),(7,7,1,96),(8,8,1,96),(9,9,1,96),(10,10,1,96),(11,11,1,96),(12,12,1,96),(13,13,1,96),(14,14,1,96),(15,15,1,96),(16,1,2,96),(17,2,2,96),(18,3,2,96),(19,4,2,96),(20,5,2,96),(21,6,2,96),(22,7,2,96),(23,8,2,96),(24,9,2,96),(25,10,2,96),(26,11,2,96),(27,12,2,96),(28,13,2,96),(29,14,2,96),(30,15,2,96);
/*!40000 ALTER TABLE `fitness_ideal_recovery_times` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fitness_lifts`
--

DROP TABLE IF EXISTS `fitness_lifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fitness_lifts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `exercise_id` int(10) unsigned NOT NULL,
  `workout_structure_id` int(10) unsigned NOT NULL,
  `total_reps` float unsigned NOT NULL,
  `weight` float NOT NULL,
  `datetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=255 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fitness_lifts`
--

LOCK TABLES `fitness_lifts` WRITE;
/*!40000 ALTER TABLE `fitness_lifts` DISABLE KEYS */;
INSERT INTO `fitness_lifts` (`id`, `exercise_id`, `workout_structure_id`, `total_reps`, `weight`, `datetime`) VALUES (1,1,1,30,95,'2018-06-20 12:00:00'),(2,2,1,30,95,'2018-06-20 12:00:00'),(3,4,1,30,45,'2018-06-20 12:00:00'),(4,3,1,30,45,'2018-06-20 12:00:00'),(5,6,1,20,15,'2018-06-20 12:00:00'),(6,1,1,30,97.5,'2018-06-23 12:00:00'),(7,2,1,30,97.5,'2018-06-23 12:00:00'),(8,4,1,26,47.5,'2018-06-23 12:00:00'),(9,3,1,26,47.5,'2018-06-23 12:00:00'),(10,5,1,30,20,'2018-06-23 12:00:00'),(11,6,1,28,12.5,'2018-06-23 12:00:00'),(12,4,1,30,47.5,'2018-06-27 12:00:00'),(13,3,1,27,47.5,'2018-06-27 12:00:00'),(14,5,1,21,22.5,'2018-06-27 12:00:00'),(15,6,1,26,12.5,'2018-06-27 12:00:00'),(16,4,1,26,50,'2018-07-01 12:00:00'),(17,3,1,30,47.5,'2018-07-01 12:00:00'),(18,5,1,23,22.5,'2018-07-01 12:00:00'),(19,6,1,28,12.5,'2018-07-01 12:00:00'),(20,4,1,28,50,'2018-07-06 12:00:00'),(21,3,1,26,50,'2018-07-06 12:00:00'),(22,7,1,23,0,'2018-07-06 12:00:00'),(23,6,1,24,12.5,'2018-07-06 12:00:00'),(24,5,1,26,22.5,'2018-07-07 12:00:00'),(25,4,1,30,50,'2018-07-11 12:00:00'),(26,3,1,30,50,'2018-07-11 12:00:00'),(27,7,1,25,0,'2018-07-11 12:00:00'),(28,6,1,25,12.5,'2018-07-11 12:00:00'),(29,14,1,35,0,'2018-07-21 11:01:00'),(30,16,1,24,0,'2018-07-21 11:31:00'),(31,17,1,29,0,'2018-07-21 11:55:00'),(32,4,1,27,52.5,'2018-07-22 18:00:00'),(33,3,1,26,52.5,'2018-07-22 18:00:00'),(34,8,1,28,20,'2018-07-22 18:00:00'),(35,6,1,27,12.5,'2018-07-22 18:00:00'),(36,9,1,14,0,'2018-07-22 18:00:00'),(37,12,1,30,30,'2018-07-25 17:45:00'),(38,13,1,35,30,'2018-07-25 17:45:00'),(39,10,1,28,30,'2018-07-25 17:45:00'),(40,11,1,30,0,'2018-07-25 19:00:00'),(41,1,1,26,100,'2018-07-25 20:55:00'),(42,2,1,30,100,'2018-07-25 20:55:00'),(43,3,1,28,52.5,'2018-07-25 20:55:00'),(44,4,1,28,52.5,'2018-07-26 21:30:00'),(45,5,1,26,22.5,'2018-07-26 21:30:00'),(46,18,1,24,0,'2018-07-26 21:30:00'),(47,6,1,30,12.5,'2018-07-27 19:15:00'),(48,9,1,17,0,'2018-07-27 19:15:00'),(49,6,1,30,12.5,'2018-08-04 00:15:00'),(50,16,1,25,0,'2018-08-10 22:35:00'),(51,14,1,35,0,'2018-08-10 23:13:00'),(52,6,1,31,12.5,'2018-08-11 00:23:00'),(53,3,1,26,55,'2018-08-11 10:46:00'),(54,17,1,30,0,'2018-08-11 23:36:00'),(55,1,1,30,100,'2018-08-11 23:45:00'),(56,2,1,30,100,'2018-08-11 23:54:00'),(57,1,1,30,100,'2018-08-18 16:00:00'),(58,2,1,30,100,'2018-08-18 16:00:00'),(59,4,1,27,50,'2018-08-18 16:20:00'),(60,3,1,24,55,'2018-08-18 16:20:00'),(61,8,1,30,20,'2018-08-19 15:17:00'),(62,5,1,30,20,'2018-08-19 15:24:00'),(63,6,1,30,12.5,'2018-08-19 15:28:00'),(64,9,1,16,0,'2018-08-19 15:33:00'),(65,12,1,31,30,'2018-08-19 15:40:00'),(66,13,1,32,30,'2018-08-19 15:45:00'),(67,14,1,35,0,'2018-08-19 15:53:00'),(68,10,1,28,30,'2018-08-22 19:26:00'),(69,4,1,26,50,'2018-08-22 19:34:00'),(70,3,1,25,55,'2018-08-22 19:39:00'),(71,18,1,25,0,'2018-08-22 19:45:00'),(72,8,1,32,20,'2018-08-22 19:58:00'),(73,1,1,30,100,'2018-08-24 19:47:00'),(74,13,1,30,32.5,'2018-08-24 19:59:00'),(75,12,1,30,32.5,'2018-08-24 20:05:00'),(76,5,1,24,22.5,'2018-08-24 20:12:00'),(77,6,1,24,15,'2018-08-24 20:18:00'),(78,9,1,16,0,'2018-08-24 20:23:00'),(83,2,1,30,102.5,'2018-08-25 11:09:00'),(84,14,1,30,2.5,'2018-08-25 11:14:00'),(85,11,1,30,0,'2018-08-25 11:19:00'),(86,3,1,28,55,'2018-08-25 16:04:00'),(87,4,1,30,52.5,'2018-08-26 20:46:00'),(88,10,1,30,30,'2018-08-26 20:53:00'),(89,8,1,32,20,'2018-08-26 21:01:00'),(90,7,1,26,0,'2018-08-26 21:06:00'),(91,16,1,28,0,'2018-08-27 16:54:00'),(92,13,1,30,32.5,'2018-08-27 22:29:00'),(93,12,1,30,32.5,'2018-08-27 22:34:00'),(94,6,1,27,15,'2018-08-27 22:40:00'),(95,3,1,30,55,'2018-08-28 22:37:00'),(96,1,1,30,102.5,'2018-08-28 22:46:00'),(97,14,1,30,5,'2018-08-28 22:54:00'),(98,4,1,25,55,'2018-08-29 21:52:00'),(99,8,1,30,22.5,'2018-08-29 21:59:00'),(100,16,1,29,0,'2018-09-02 09:18:00'),(101,3,1,28,57.5,'2018-09-07 20:45:00'),(102,8,1,26,25,'2018-09-07 20:52:00'),(103,6,1,30,15,'2018-09-07 20:58:00'),(104,4,1,25,55,'2018-09-08 10:27:00'),(105,1,1,27,105,'2018-09-08 10:35:00'),(106,5,1,23,22.5,'2018-09-08 10:41:00'),(107,2,1,33,105,'2018-09-09 19:38:00'),(108,13,1,30,35,'2018-09-09 19:51:00'),(109,12,1,30,35,'2018-09-09 19:58:00'),(110,14,1,35,7.5,'2018-09-09 20:04:00'),(111,18,1,27,0,'2018-09-09 20:13:00'),(112,4,1,25,55,'2018-09-11 21:56:00'),(113,1,1,29,105,'2018-09-11 22:02:00'),(114,16,1,26,0,'2018-09-11 22:08:00'),(115,6,1,21,17.5,'2018-09-11 22:15:00'),(116,3,1,26,57.5,'2018-09-12 19:43:00'),(117,10,1,29,32.5,'2018-09-12 19:52:00'),(118,8,1,30,25,'2018-09-12 19:59:00'),(119,11,1,29,2.5,'2018-09-12 20:05:00'),(120,9,1,19,0,'2018-09-12 20:12:00'),(121,1,1,30,105,'2018-09-14 21:41:00'),(122,4,1,27,55,'2018-09-14 21:48:00'),(123,5,1,27,22.5,'2018-09-14 21:55:00'),(124,6,1,24,17.5,'2018-09-14 22:02:00'),(125,3,1,29,57.5,'2018-09-15 10:25:00'),(126,3,1,32,57.5,'2018-09-18 21:12:00'),(127,6,1,26,17.5,'2018-09-18 21:15:00'),(128,8,1,26,27.5,'2018-09-18 21:27:00'),(129,1,1,28,107.5,'2018-09-19 20:49:00'),(130,4,1,29,55,'2018-09-19 20:56:00'),(131,13,1,32,37.5,'2018-09-19 21:06:00'),(132,12,1,29,37.5,'2018-09-19 21:12:00'),(133,5,1,30,22.5,'2018-09-19 21:19:00'),(134,14,1,30,10,'2018-09-19 21:24:00'),(135,2,1,30,107.5,'2018-09-21 21:52:00'),(136,9,1,19,0,'2018-09-21 21:58:00'),(137,3,1,25,60,'2018-09-22 10:41:00'),(138,4,1,28,55,'2018-09-22 16:42:00'),(139,16,1,25,0,'2018-09-22 17:43:00'),(140,4,1,27,55,'2018-09-25 21:31:00'),(141,3,1,27,60,'2018-09-25 21:37:00'),(142,6,1,22,17.5,'2018-09-25 21:47:00'),(143,10,1,30,32.5,'2018-09-25 21:55:00'),(144,18,1,27,0,'2018-09-25 22:01:00'),(145,11,1,26,2.5,'2018-09-25 22:09:00'),(146,16,1,29,0,'2018-09-27 16:45:00'),(147,3,4,42,55,'2018-09-28 22:22:00'),(155,19,2,25,90,'2018-10-03 20:30:00'),(156,20,2,25,90,'2018-10-03 20:30:00'),(157,21,2,25,80,'2018-10-03 20:30:00'),(158,22,2,25,30,'2018-10-04 21:15:00'),(159,23,2,25,155,'2018-10-04 21:15:00'),(160,24,2,25,55,'2018-10-04 21:15:00'),(161,25,2,25,60,'2018-10-04 21:15:00'),(162,26,2,22,45,'2018-10-04 21:15:00'),(163,27,2,22,65,'2018-10-04 21:15:00'),(164,23,2,25,165,'2018-10-09 21:00:00'),(165,24,2,25,62.5,'2018-10-09 21:00:00'),(166,32,2,25,32.5,'2018-10-09 21:00:00'),(167,29,2,25,120,'2018-10-10 21:00:00'),(168,30,2,24,35,'2018-10-10 21:00:00'),(169,20,2,21,115,'2018-10-10 21:00:00'),(170,31,2,25,150,'2018-10-10 21:00:00'),(171,23,2,24,175,'2018-10-12 19:00:00'),(172,24,2,23,65,'2018-10-12 20:00:00'),(173,32,2,25,35,'2018-10-12 20:00:00'),(174,27,2,25,65,'2018-10-12 20:15:00'),(175,14,2,25,15,'2018-10-12 20:20:00'),(176,30,2,25,35,'2018-10-14 20:25:00'),(177,26,2,19,45,'2018-10-14 20:45:00'),(178,1,2,25,107.5,'2018-10-14 21:00:00'),(180,23,2,23,180,'2018-10-16 18:48:00'),(181,33,2,25,135,'2018-10-16 19:19:00'),(182,20,2,25,105,'2018-10-16 19:05:00'),(183,24,2,24,65,'2018-10-16 19:32:00'),(184,3,2,25,65,'2018-10-18 22:18:00'),(186,8,2,25,30,'2018-10-18 22:32:00'),(187,18,2,25,0,'2018-10-18 22:46:00'),(188,23,2,25,180,'2018-10-19 19:30:00'),(189,24,2,24,65,'2018-10-19 19:43:00'),(190,32,2,25,40,'2018-10-19 19:57:00'),(191,23,2,22,185,'2018-10-22 19:22:00'),(192,31,2,22,165,'2018-10-22 19:56:00'),(193,34,2,25,115,'2018-10-22 20:10:00'),(194,35,2,25,75,'2018-10-22 20:30:00'),(195,36,9,53,45,'2018-10-22 20:30:00'),(197,24,9,52,45,'2018-10-22 20:30:00'),(199,33,2,25,95,'2018-10-24 22:01:00'),(200,19,2,25,100,'2018-10-24 22:13:00'),(201,25,2,25,65,'2018-10-24 22:26:00'),(202,23,2,20,185,'2018-10-26 19:41:00'),(203,24,2,25,62.5,'2018-10-26 19:54:00'),(204,31,2,25,155,'2018-10-26 20:06:00'),(205,23,2,21,190,'2018-10-31 20:11:00'),(206,30,2,22,40,'2018-10-31 20:28:00'),(207,6,2,21,20,'2018-10-31 20:42:00'),(208,27,2,24,70,'2018-10-31 20:56:00'),(209,3,2,25,67.5,'2018-11-05 23:15:00'),(210,23,2,23,190,'2018-11-06 19:09:00'),(211,23,3,1,205,'2018-11-06 19:09:00'),(212,24,2,22,65,'2018-11-06 19:20:00'),(213,6,4,18,20,'2018-11-06 19:40:00'),(214,37,4,26,90,'2018-11-06 19:50:00'),(215,37,4,25,45,'2018-11-06 19:40:00'),(229,14,4,100,0,'2018-11-08 21:31:00'),(230,17,4,55,0,'2018-11-08 21:55:00'),(231,11,4,30,0,'2018-11-08 22:13:00'),(232,36,2,25,62.5,'2018-11-12 15:38:00'),(233,31,2,25,165,'2018-11-12 15:50:00'),(234,29,4,22,120,'2018-11-12 15:59:00'),(235,49,4,10,155,'2018-11-12 17:41:00'),(236,8,2,25,32.5,'2018-11-12 22:15:00'),(237,50,2,30,110,'2018-11-12 22:27:00'),(238,13,2,25,40,'2018-11-13 21:39:00'),(239,34,2,25,125,'2018-11-13 21:52:00'),(240,33,2,25,145,'2018-11-13 22:08:00'),(241,27,2,25,70,'2018-11-13 22:21:00'),(242,23,2,20,190,'2018-11-14 18:28:00'),(243,24,2,25,65,'2018-11-14 18:43:00'),(244,14,2,25,20,'2018-11-14 18:57:00'),(245,48,3,65,0,'2018-11-14 19:03:00'),(246,21,1,18,80,'2018-11-16 22:22:00'),(247,33,2,25,155,'2018-11-20 21:37:00'),(248,31,2,25,170,'2018-11-20 21:50:00'),(249,50,2,25,120,'2018-11-20 22:01:00'),(250,51,4,9,80,'2018-11-20 22:06:00'),(251,23,2,17,190,'2018-11-21 19:48:00'),(252,52,2,25,80,'2018-11-21 20:02:00'),(253,49,2,24,155,'2018-11-21 20:17:00'),(254,8,2,25,35,'2018-11-21 20:29:00');
/*!40000 ALTER TABLE `fitness_lifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fitness_measurements_body_weight`
--

DROP TABLE IF EXISTS `fitness_measurements_body_weight`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fitness_measurements_body_weight` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `datetime` datetime NOT NULL,
  `pounds` float unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fitness_measurements_body_weight`
--

LOCK TABLES `fitness_measurements_body_weight` WRITE;
/*!40000 ALTER TABLE `fitness_measurements_body_weight` DISABLE KEYS */;
INSERT INTO `fitness_measurements_body_weight` (`id`, `datetime`, `pounds`) VALUES (1,'2018-06-04 18:00:00',147),(2,'2018-07-01 10:30:00',149),(3,'2018-07-08 11:05:00',151.6),(4,'2018-07-22 12:30:00',152.8),(5,'2018-07-29 08:42:00',151),(6,'2018-08-05 09:45:00',150.4),(7,'2018-08-12 09:12:00',151.6),(8,'2018-08-19 09:54:00',151.6),(9,'2018-09-09 09:05:00',151.8),(10,'2018-09-16 08:07:00',154.2),(11,'2018-09-23 10:08:00',153.2),(12,'2018-09-30 11:17:00',155),(13,'2018-10-21 09:54:00',155.6);
/*!40000 ALTER TABLE `fitness_measurements_body_weight` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fitness_measurements_circumferences`
--

DROP TABLE IF EXISTS `fitness_measurements_circumferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fitness_measurements_circumferences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `circumference_id` int(10) unsigned NOT NULL,
  `value` float unsigned NOT NULL COMMENT 'In inches',
  `datetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fitness_measurements_circumferences`
--

LOCK TABLES `fitness_measurements_circumferences` WRITE;
/*!40000 ALTER TABLE `fitness_measurements_circumferences` DISABLE KEYS */;
INSERT INTO `fitness_measurements_circumferences` (`id`, `circumference_id`, `value`, `datetime`) VALUES (1,1,14.375,'2018-05-28 12:00:00'),(2,2,44.25,'2018-05-28 12:00:00'),(3,3,37.5,'2018-05-28 12:00:00'),(5,4,12.0625,'2018-05-28 12:00:00'),(6,5,11.125,'2018-05-28 12:00:00'),(7,6,29.5,'2018-05-28 12:00:00'),(8,7,34.5,'2018-05-28 12:00:00'),(9,8,20.1875,'2018-05-28 12:00:00'),(10,9,15,'2018-05-28 12:00:00'),(11,1,14.5,'2018-07-29 10:00:00'),(12,2,44.25,'2018-07-29 10:00:00'),(13,3,38.5,'2018-07-29 10:00:00'),(14,4,12.125,'2018-07-29 10:00:00'),(15,5,11,'2018-07-29 10:00:00'),(16,6,29.625,'2018-07-29 10:00:00'),(17,7,35.25,'2018-07-29 10:00:00'),(18,8,20.5,'2018-07-29 10:00:00'),(19,9,14.75,'2018-07-29 10:00:00'),(20,1,14.5,'2018-09-30 12:00:00'),(21,2,44.625,'2018-09-30 12:00:00'),(22,3,39.25,'2018-09-30 12:00:00'),(23,4,12.375,'2018-09-30 12:00:00'),(24,5,11.1875,'2018-09-30 12:00:00'),(25,6,29.875,'2018-07-29 10:00:00'),(26,7,35.875,'2018-09-30 12:00:00'),(27,8,20.875,'2018-09-30 12:00:00'),(28,9,14.8125,'2018-09-30 12:00:00');
/*!40000 ALTER TABLE `fitness_measurements_circumferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fitness_muscles`
--

DROP TABLE IF EXISTS `fitness_muscles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fitness_muscles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `common_name` tinytext NOT NULL COMMENT 'Will be displayed on HomeBase Home Page',
  `anatomical_name` tinytext,
  `circumference_id` tinyint(4) NOT NULL COMMENT 'Foreign Key to fitness_circumferences',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fitness_muscles`
--

LOCK TABLES `fitness_muscles` WRITE;
/*!40000 ALTER TABLE `fitness_muscles` DISABLE KEYS */;
INSERT INTO `fitness_muscles` (`id`, `common_name`, `anatomical_name`, `circumference_id`) VALUES (1,'traps','trapezius',1),(2,'shoulders','deltoids',2),(3,'chest','pectoralis',3),(4,'biceps','biceps brachii',4),(5,'triceps','triceps brachii',4),(6,'forearms','brachioradialis',5),(7,'lats','latissimus dorsi',3),(8,'middle back','rhomboids',6),(9,'lower back',NULL,6),(10,'obliques',NULL,6),(11,'abs','rectus abdominis',6),(12,'glutes','gluteus maximus',7),(13,'quads','quadriceps',8),(14,'hamstrings','biceps femoris',8),(15,'calves','gastrocnemius',9);
/*!40000 ALTER TABLE `fitness_muscles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fitness_pivot_exercises_equipment`
--

DROP TABLE IF EXISTS `fitness_pivot_exercises_equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fitness_pivot_exercises_equipment` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `exercise_id` smallint(5) unsigned NOT NULL,
  `equipment_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fitness_pivot_exercises_equipment`
--

LOCK TABLES `fitness_pivot_exercises_equipment` WRITE;
/*!40000 ALTER TABLE `fitness_pivot_exercises_equipment` DISABLE KEYS */;
INSERT INTO `fitness_pivot_exercises_equipment` (`id`, `exercise_id`, `equipment_id`) VALUES (1,1,2),(2,2,2),(3,3,2),(4,4,1),(5,4,8),(6,5,1),(7,6,1),(8,7,3),(9,8,1),(10,8,8),(11,9,9),(12,10,1),(13,10,8),(14,11,4),(15,12,1),(16,13,1),(17,14,4),(18,15,10),(19,16,4),(20,17,4),(21,18,4),(22,18,8),(23,19,5),(24,20,5),(25,21,5),(26,22,5),(27,22,8),(28,23,6),(29,23,8),(30,24,5),(31,25,1),(32,26,2),(33,26,8),(34,27,1),(35,28,10),(36,29,5),(37,30,1),(38,31,5),(39,32,1),(40,32,8),(41,33,6),(42,33,11),(43,34,6),(44,35,6),(45,35,12),(46,36,5),(47,37,7),(48,43,4),(49,44,4),(50,47,4),(51,48,4),(52,49,6),(53,50,5),(54,51,6),(55,52,5);
/*!40000 ALTER TABLE `fitness_pivot_exercises_equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fitness_pivot_exercises_muscles`
--

DROP TABLE IF EXISTS `fitness_pivot_exercises_muscles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fitness_pivot_exercises_muscles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `exercise_id` int(10) unsigned NOT NULL,
  `muscle_id` int(10) unsigned NOT NULL,
  `type` enum('primary','secondary') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fitness_pivot_exercises_muscles`
--

LOCK TABLES `fitness_pivot_exercises_muscles` WRITE;
/*!40000 ALTER TABLE `fitness_pivot_exercises_muscles` DISABLE KEYS */;
INSERT INTO `fitness_pivot_exercises_muscles` (`id`, `exercise_id`, `muscle_id`, `type`) VALUES (1,1,1,'primary'),(2,2,15,'primary'),(3,3,4,'primary'),(4,4,3,'primary'),(5,5,5,'primary'),(6,6,2,'primary'),(7,7,11,'primary'),(8,8,6,'primary'),(9,9,7,'primary'),(10,10,8,'primary'),(11,11,9,'primary'),(12,12,13,'primary'),(13,13,14,'primary'),(14,14,12,'primary'),(15,15,10,'primary'),(16,16,5,'primary'),(17,17,11,'primary'),(18,18,10,'primary'),(19,18,11,'primary'),(20,19,2,'primary'),(21,20,2,'primary'),(22,21,4,'primary'),(23,22,3,'primary'),(24,23,3,'primary'),(25,24,5,'primary'),(26,25,1,'primary'),(27,26,6,'primary'),(28,27,15,'primary'),(29,28,11,'primary'),(30,29,8,'primary'),(31,30,4,'primary'),(32,31,7,'primary'),(33,32,2,'primary'),(34,33,13,'primary'),(35,34,9,'primary'),(36,34,14,'secondary'),(37,35,8,'primary'),(38,35,6,'secondary'),(39,36,4,'primary'),(40,37,8,'primary'),(47,43,3,'primary'),(48,43,5,'secondary'),(49,44,5,'primary'),(50,44,3,'secondary'),(53,47,13,'primary'),(54,48,10,'primary'),(55,48,11,'secondary'),(56,49,1,'primary'),(57,49,6,'secondary'),(58,50,2,'primary'),(59,50,5,'secondary'),(60,50,4,'secondary'),(61,51,4,'primary'),(62,52,5,'primary');
/*!40000 ALTER TABLE `fitness_pivot_exercises_muscles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fitness_runs`
--

DROP TABLE IF EXISTS `fitness_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fitness_runs` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `datetime` datetime NOT NULL,
  `miles` float NOT NULL,
  `seconds` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fitness_runs`
--

LOCK TABLES `fitness_runs` WRITE;
/*!40000 ALTER TABLE `fitness_runs` DISABLE KEYS */;
INSERT INTO `fitness_runs` (`id`, `datetime`, `miles`, `seconds`) VALUES (1,'2018-06-29 17:45:00',1,513),(2,'2018-07-03 16:45:00',0.5,232),(3,'2018-07-02 18:20:00',1,499),(4,'2018-07-06 17:25:00',1,458),(5,'2018-07-11 18:37:00',1,467),(6,'2018-07-19 10:35:00',1,490),(7,'2018-10-03 22:18:00',1,486),(8,'2018-10-09 22:25:00',1,478),(9,'2018-10-10 21:46:00',1,497),(10,'2018-10-26 20:36:00',1,463),(11,'2018-11-12 21:53:00',1,460),(12,'2018-11-16 22:13:00',1,449),(13,'2018-11-20 22:14:00',0.5,234);
/*!40000 ALTER TABLE `fitness_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fitness_workout_structures`
--

DROP TABLE IF EXISTS `fitness_workout_structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fitness_workout_structures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sets_per_exercise` tinyint(3) unsigned NOT NULL,
  `reps_per_set` tinyint(3) unsigned NOT NULL,
  `cadence` tinyint(3) unsigned NOT NULL COMMENT 'In seconds',
  `rest` smallint(5) unsigned NOT NULL COMMENT 'In seconds',
  `name` tinytext COMMENT 'Descriptive name for this workout structure',
  `description` text COMMENT 'Description of the purpose and functionality of this workout structure',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fitness_workout_structures`
--

LOCK TABLES `fitness_workout_structures` WRITE;
/*!40000 ALTER TABLE `fitness_workout_structures` DISABLE KEYS */;
INSERT INTO `fitness_workout_structures` (`id`, `sets_per_exercise`, `reps_per_set`, `cadence`, `rest`, `name`, `description`) VALUES (1,3,10,4,45,'Bodybuilder','Meant to promote hypertrophy and vascularity.'),(2,5,5,5,120,'5x5x2','Meant to promote strength gain. First set should be performed as a warm-up set at ~60% weight; Remaining 4 sets should be 85% 1RM. Example set: Bench Press - 5 @135 5+5+5+5 @180'),(3,1,15,3,180,'One Rep Max','Used to test one rep max for exercises.'),(4,100,100,0,0,'Freestyle','A freestyle structure meant to be used as a flexible structure to allow working out with others or with strange circumstances such as super-setting or pyramids, or experimenting with different timings.'),(9,2,40,2,80,'Hines Pyramid','Pair two opposite motion exercises (ex. Tricep Pushdown and Dumbbell curls.) Perform a 4x10 (0 rest) with descending weight. Immediately switch exercises. Perform a 4x10 (0 rest) descending. Then switch back to first excercise (no rest) and ascend with a 4x10 to original weight. Immediately switch back to second exercise and do the same. Gives a massive pump to quickly work both muscles.');
/*!40000 ALTER TABLE `fitness_workout_structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weather_cities`
--

DROP TABLE IF EXISTS `weather_cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weather_cities` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `lat` float NOT NULL,
  `lon` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weather_cities`
--

LOCK TABLES `weather_cities` WRITE;
/*!40000 ALTER TABLE `weather_cities` DISABLE KEYS */;
INSERT INTO `weather_cities` (`id`, `name`, `lat`, `lon`) VALUES (1,'austin',30.2672,-97.7431),(3,'raleigh',35.7796,-78.6382),(4,'albany',42.75,-73.8),(5,'fallon',39.45,-118.78),(6,'phoenix',33.43,-112);
/*!40000 ALTER TABLE `weather_cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'jaysoftw_homebase'
--

--
-- Dumping routines for database 'jaysoftw_homebase'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-22 12:41:18
